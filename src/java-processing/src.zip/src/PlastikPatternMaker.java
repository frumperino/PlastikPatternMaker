import java.io.IOException;
import org.goodwires.installations.plastikophobia.Plastikophobia2019;
import processing.core.PApplet;

public class PlastikPatternMaker extends PApplet 
{
	Plastikophobia2019 pm;
	
	public static void main(String[] args) 
	{
		PApplet.main("PlastikPatternMaker");
	}
	
	public void settings()
	{
		size(840,840,P3D);
	}
	
	public void setup()
	{
		try
		{
			pm = new Plastikophobia2019(this);
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void mousePressed()
	{
		pm.ui_handleMouseDown(mouseX,mouseY);
	}
	
	public void mouseReleased()
	{
		pm.ui_handleMouseUp(mouseX,mouseY);
	}
	
	public void mouseDragged()
	{
		pm.ui_handleMouseDragged(mouseX,mouseY);
	}
	
	public void keyPressed()
	{
		pm.ui_handleKey(keyCode);
	}

	public void draw()
	{
		pm.step(g);
	}
	
}
