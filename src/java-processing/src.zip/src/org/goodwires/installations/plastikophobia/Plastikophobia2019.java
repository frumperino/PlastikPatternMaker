package org.goodwires.installations.plastikophobia;

import processing.core.*;
import java.io.IOException;
import org.goodwires.LEDpatternMaker.*;
import controlP5.*;

public class Plastikophobia2019 extends LEDpatternMaker
{

	ControlP5 cp5;

	private static final int id_btn_exit = 100;
	private static final int id_btn_load = 101;
	private static final int id_btn_exp_pat = 102;
	private static final int id_btn_exp_vid = 103;
	private static final int id_btn_runstop = 104;
	
	private static final int id_knob_time = 201;
	private static final int id_knob_speed = 202;

	private static final int id_radio_progmode = 301;
	private static final int id_radio_filtermode = 302;
	private static final int id_radio_dithermode = 303;
	private static final int id_radio_sampleLayout = 304;

	private static final float speedknob_exp = 12.0f;
	private static final float speedknob_offset = 0.54f;
	private static final float speedknob_keystep = 0.05f;

	private static final int _BGCOLOR = 0xFF161616;

	private ControlListener p5_eventHandler;
	private CallbackListener p5_buttonHandler;
	private CallbackListener p5_knobHandler;
	
	private Button p5_btn_run;
	private Slider p5_knob_timeline;
	private Knob p5_knob_speed;
	private Textlabel p5_label;
	private RadioButton p5_radio_oscmode;
	private RadioButton p5_radio_filtermode;
	private RadioButton p5_radio_dithermode;
	private RadioButton p5_radio_sampleLayout;
	
	private boolean p5_suppress_radio_event = false;
	
	PImage titleImage;
	PImage overlayImage;
	
	public Plastikophobia2019(PApplet pap) throws IOException 
	{
		super(pap);
		
		this.videoExportFrameRate = 60; // 60 Hz
		this.patternExportFrameRate = 120; // 120 Hz
		this.previewFrameRate = 60; // 60 Hz
		
		pap.frameRate(previewFrameRate);

		titleImage = Util.getResImage(this, getBasePath() + "/res/title.png");
		overlayImage = Util.getResImage(this, getBasePath() + "/res/overlay.png");
		
		// fairylight samplers

		SamplerConfig scf_fairy_1 = new SamplerConfig()
				.spatialSamples(20)
				.temporalSamples(4)
				.range(0f, 1f)
				.spatialSpread(1f);
		
		SamplerConfig scf_fairy_2 = scf_fairy_1.clone()
				.range(0.00f, 0.50f);

		SamplerConfig scf_fairy_3L = scf_fairy_1.clone()
				.range(0.00f, 0.50f);
		
		SamplerConfig scf_fairy_3R = scf_fairy_1.clone()
				.range(0.50f, 1.00f);

		SamplerConfig scf_fairy_4L = scf_fairy_1.clone()
				.range(0.00f, 0.25f);

		SamplerConfig scf_fairy_4R = scf_fairy_1.clone()
				.range(0.25f, 0.50f);
		
		pm_createSampler("FAIRY_L",11)
		.setOutputColorSpace("sRGB_linear")
		.setMono(true)
		.setCadence(1) // 120Hz
		.trim(0.2f,0.9f)
		.storeConfig(1, scf_fairy_1)
		.storeConfig(2, scf_fairy_2)
		.storeConfig(3, scf_fairy_3L)
		.storeConfig(4, scf_fairy_4L)
		.loadConfig(1);
		;

		pm_createSampler("FAIRY_R",18)
		.setOutputColorSpace("sRGB_linear")
		.setMono(true)
		.setCadence(1) // 120Hz
		.trim(0.0f, 0.9f)
		.storeConfig(1, scf_fairy_1)
		.storeConfig(2, scf_fairy_2)
		.storeConfig(3, scf_fairy_3R)
		.storeConfig(4, scf_fairy_4R)
		.loadConfig(1)
		;
		
		// floor strip samplers
		
		SamplerConfig scf_floor_1 = new SamplerConfig()
				.spatialSamples(2)
				.temporalSamples(4)
				.range(0f, 1f)
				.spatialSpread(1f);
		
		SamplerConfig scf_floor_2 = scf_floor_1.clone()
				.range(0.50f, 1.00f);

		SamplerConfig scf_floor_3L = scf_floor_1.clone()
				.range(0.00f, 0.50f);

		SamplerConfig scf_floor_3R = scf_floor_1.clone()
				.range(0.50f, 1.00f);

		SamplerConfig scf_floor_4L = scf_floor_1.clone()
				.range(0.50f, 0.75f);

		SamplerConfig scf_floor_4R = scf_floor_1.clone()
				.range(0.75f, 1.00f);
		
		pm_createSampler("FLOOR_L",150)
		.setOutputColorSpace("ws2812")
		.setMono(false)
		.setCadence(4) // 30Hz
		.trim(0.15f, 1.0f)
		.storeConfig(1,scf_floor_1)
		.storeConfig(2,scf_floor_2)
		.storeConfig(3,scf_floor_3L)
		.storeConfig(4,scf_floor_4L)
		.loadConfig(1);
		;

		pm_createSampler("FLOOR_R",150)
		.setOutputColorSpace("ws2812")
		.setMono(false)
		.setCadence(4) // 30Hz
		.trim(0.15f, 0.90f)
		.storeConfig(1,scf_floor_1)
		.storeConfig(2,scf_floor_2)
		.storeConfig(3,scf_floor_3R)
		.storeConfig(4,scf_floor_4R)
		.loadConfig(1);
		;

		// configure visualizer 
		// fairylights
		
		String[] fairyMapL = {  "L1","L2","L3","L4","L5","L6","L7","L8","L9","L10","L11" };
		String[] fairyMapR = {  "R1","R2","R3","R4","R5","R6","R7","R8","R9","R10",
							 	"R11","R12","R13","R14","R15","R16","R17","R18" };

		PShape fairySVG = loadSVG("/res/map-fairylights.svg");
		VisualizerModel vmod = new VisualizerModel(pap,830,350,0,485,1);
		vmod.setBackgroundColor(_BGCOLOR);
		pm_registerVisualizer(vmod);
		
		VisualizerGroup fairyL = new VisualizerGroup(
				Util.extractNamedShapes(fairySVG, fairyMapL));
		fairyL.setOutputColorSpace("sRGB_linear");
		vmod.registerGroup(fairyL, "FAIRY_L", 10,5); // should have 11 members
		
		VisualizerGroup fairyR = new VisualizerGroup(
				Util.extractNamedShapes(fairySVG, fairyMapR));
		fairyR.setOutputColorSpace("sRGB_linear");
		vmod.registerGroup(fairyR, "FAIRY_R", 10,5); // should have 18 members

		// floor strips

		PShape floorSVG = loadSVG("/res/map-strings.svg");
		PShape[] floorStripL = Util.extractLayerMembers(floorSVG, "string1"); // 150 members
		PShape[] floorStripR = Util.extractLayerMembers(floorSVG, "string2"); // 150 members
		
		VisualizerGroup floorL = VisualizerGroup.createCircleGroup(floorStripL,8);
		floorL.setOutputColorSpace("ws2812");
		vmod.registerGroup(floorL, "FLOOR_L", 70, 75);
		
		VisualizerGroup floorR = VisualizerGroup.createCircleGroup(floorStripR,8);
		floorR.setOutputColorSpace("ws2812");
		vmod.registerGroup(floorR, "FLOOR_R", 70, 75);

		// proxy window
		
		pm_placeProxyWindow(800, 400, 30, 25);

		// setup CP5 panel items
		
		cp5 = new ControlP5(pap);
		
		p5_eventHandler = new ControlListener() 
		{
			@Override
			public void controlEvent(ControlEvent event) 
			{
				int id = event.getId();
				switch(id)
				{
					case id_radio_progmode:
					{
						if (!p5_suppress_radio_event)
						{
							int v = (int) event.getValue();
							pm_setOscillatorMode(v-1);
						}
					} break;
					
					case id_radio_filtermode:
					{
						if (!p5_suppress_radio_event)
						{
							int v = (int) event.getValue();
							pm_setFilterMode(v-1);
						}
					} break;
					
					case id_radio_dithermode:
					{
						if (!p5_suppress_radio_event)
						{
							int v = (int) event.getValue();
							pm_setDitherMode(v-1);
						}
					} break;
					
					case id_radio_sampleLayout:
					{
						if (!p5_suppress_radio_event)
						{
							int v = (int) event.getValue();
							pm_loadSamplerConfigPreset(v);
						}
					} break;
					
				}
				
				p5_suppress_radio_event = false;
			}
		};
		
		cp5.addListener(p5_eventHandler);
		
		p5_buttonHandler  = new CallbackListener() 
		{
			@Override
			public void controlEvent(CallbackEvent arg0)
			{
				int id = arg0.getController().getId();
				switch(id)
				{
					case id_btn_exit: break;
					case id_btn_load: pm_promptImportImage(); break;
					case id_btn_exp_pat: pm_promptExportPattern(); break;
					case id_btn_exp_vid: pm_promptExportVideo(); break;
					case id_btn_runstop: pm_toggleRunning(); break;
					default: break;
				}
			}

		};
		
		p5_knobHandler = new CallbackListener()
		{
			@Override
			public void controlEvent(CallbackEvent arg0)
			{
				int id = arg0.getController().getId();
				float v = arg0.getController().getValue();
				switch(id)
				{
					case id_knob_speed: pm_requestSpeed(speedKnobScale(v)); break;
					case id_knob_time: pm_requestTime(v); break;
					default:break;
				}
			}
		};
		
		cp5.addButton("Open image")
				.setValue(0)
				.setPosition(10,490)
				.setSize(100,19)
				.setColor(ControlP5.THEME_RETRO)
				.setId(id_btn_load)
				.onClick(p5_buttonHandler);
		
		cp5.addButton("Export pattern")
				.setValue(1)
				.setPosition(10,515)
				.setSize(100,19)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setId(id_btn_exp_pat)
				.onClick(p5_buttonHandler)
				;
		
		cp5.addButton("Export video")
				.setValue(2)
				.setPosition(10,540)
				.setSize(100,19)
				.setColor(ControlP5.THEME_RETRO)
				.setId(id_btn_exp_vid)
				.onClick(p5_buttonHandler)
				;
		
		p5_knob_speed = cp5.addKnob("Speed")
				.setPosition(695,500)
				.setRange(0, 1)
				.setNumberOfTickMarks(11)
				.setRadius(30)
				.setTickMarkLength(4)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setDragDirection(Knob.HORIZONTAL)
				.setValue(0.5f)
				.setId(id_knob_speed)
				.snapToTickMarks(false)
				.onDrag(p5_knobHandler)
				.onChange(p5_knobHandler)
				;
		
		p5_knob_timeline = cp5.addSlider("Timeline")
				.setPosition(10,450)
				.setWidth(820)
				.setHeight(20)
				.setRange(0.0f,1.0f)
				.setValue(0.5f)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setColorTickMark(0xFF)
				.setNumberOfTickMarks(11)
				.snapToTickMarks(false)
				.setSliderMode(Slider.FLEXIBLE)
				.setId(id_knob_time)
				.onDrag(p5_knobHandler)
				.onChange(p5_knobHandler)
				.onClick(p5_knobHandler)
				;
		
		p5_knob_timeline.getCaptionLabel().align(ControlP5.RIGHT, ControlP5.BOTTOM_OUTSIDE);
		
		p5_btn_run = cp5.addButton("run")
				.setPosition(775,500)
				.setId(id_btn_runstop)
				.onChange(p5_buttonHandler)
				;
		
		p5_label = cp5.addLabel("Stat")
				.setPosition(10,10)
				;
		
		p5_radio_oscmode = cp5.addRadioButton("Progression")
				.setPosition(775,550)
				.setSize(10,10)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setItemsPerRow(1)
				.setId(id_radio_progmode)
				.setNoneSelectedAllowed(false)
				.addItem("LINEAR", 1)
				.addItem("REVERSE", 2)
				.addItem("PINGPONG", 3)
				.addItem("SINE", 4)
				;
		
		p5_radio_filtermode = cp5.addRadioButton("Filter")
				.setPosition(128,490)
				.setSize(10,10)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setItemsPerRow(1)
				.setId(id_radio_filtermode)
				.setNoneSelectedAllowed(false)
				.addItem("DIRECT", 1)     	 // no compensation (source direct)
				.addItem("CORRECTION", 2)    // color correction
				;

		p5_radio_dithermode = cp5.addRadioButton("Dither")
				.setPosition(128,525)
				.setSize(10,10)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setItemsPerRow(1)
				.setId(id_radio_dithermode)
				.setNoneSelectedAllowed(false)
				.addItem("FLAT", 1)			// no dither
				.addItem("DITHER", 2)		// floyd-steinberg 
				;
		
		p5_radio_sampleLayout = cp5.addRadioButton("Layout")
				.setPosition(350,5)
				.setSize(15,15)
				.setSpacingColumn(15)
				.setColor(ControlP5.THEME_CP5BLUE)
				.setItemsPerRow(4)
				.setId(id_radio_sampleLayout)
				.setNoneSelectedAllowed(false)
				.addItem("1", 1)
				.addItem("2", 2)
				.addItem("3", 3)
				.addItem("4", 4)
				;
		
		// setup PatternMaker UI feedback / output handler
		
		pm_registerUIFBH(new UIfeedbackHandler_I() 
		{

			@Override
			public void ui_updateTimelinePosition(float v)
			{
				p5_knob_timeline.changeValue(v);
			}
			

			@Override
			public void ui_updateSpeedKnob(float v)
			{
				// p5_knob_speed.changeValue(reverseSpeedKnobScale(v));
			}


			@Override
			public void ui_indicateExportState(boolean writing) 
			{
				changeTimelineWriteIndication(writing);
			}
			
			@Override
			public void ui_indicateRunning(boolean running) 
			{
				changeRunButtonGraphic(running);
			}

			@Override
			public void ui_updateStatusText(String text) 
			{
				p5_label.setText(text);
			}

			@Override
			public void ui_indicateOscillatorMode(int oscMode, String oscModeName)
			{
				p5_suppress_radio_event = true;
				p5_radio_oscmode.activate(oscMode);
			}

			@Override
			public void ui_indicateFilterMode(int previewMode) 
			{
				p5_suppress_radio_event = true;
				p5_radio_filtermode.activate(previewMode);
			}


			@Override
			public void ui_indicateDitherMode(int ditherMode) 
			{
				p5_suppress_radio_event = true;
				p5_radio_dithermode.activate(ditherMode);
			}
		});
		
		changeRunButtonGraphic(false);
		changeTimelineWriteIndication(false);
		
		pm_requestSpeed(0.01f);
		pm_setOscillatorMode(Oscillator.LINEAR);
		pm_setFilterMode(FILTERMODE_CC);
		pm_setDitherMode(DITHERMODE_STEINBERG);
		pm_init();
		p5_radio_sampleLayout.activate(0);
	}
	
	protected void changeTimelineWriteIndication(boolean writing)
	{
		if (writing)
		{
			p5_knob_timeline.setColor(ControlP5.THEME_RED);
		}
		else
		{
			p5_knob_timeline.setColor(ControlP5.THEME_CP5BLUE);
		}
	}

	private void changeRunButtonGraphic(boolean running)
	{
		PImage[] imgs;
		if (running)
		{
			imgs = Util.getResImageSet(this,getBasePath() + "/res/",new String[] 
					{"ppb-run-1.png","ppb-run-2.png","ppb-run-3.png"});
		}
		else
		{
			imgs = Util.getResImageSet(this,getBasePath() + "/res/",new String[] 
					{"ppb-stop-1.png","ppb-stop-2.png","ppb-stop-3.png"});
		}
		p5_btn_run.setImages(imgs);
		p5_btn_run.updateSize();

	}
	
	private float speedKnobScale(float knobPos) 
	{
		return (float) Math.pow(
				speedknob_offset+(1-speedknob_offset)*knobPos,speedknob_exp);
	}

	/*
	private float reverseSpeedKnobScale(float linearSpeedProportional) 
	{
		return (float) (( Math.pow(linearSpeedProportional,(1/speedknob_exp))
				- speedknob_offset) / (1-speedknob_offset));
	}
	*/

	public void ui_handleKey(int keyCode)
	{
		switch(keyCode)
		{
			case ' ' : pm_toggleRunning(); break;
			case 'I' : pm_cycleFilterMode(); break;
			case 'O' : pm_cycleDitherMode(); break;
			case 'P' : pm_cycleOscillatorMode(); break;
			case '[' : decrementSpeed(); break;
			case ']' : incrementSpeed(); break;
			case '1' : p5_radio_sampleLayout.activate(0); break;
			case '2' : p5_radio_sampleLayout.activate(1); break;
			case '3' : p5_radio_sampleLayout.activate(2); break;
			case '4' : p5_radio_sampleLayout.activate(3); break;
		}
	}

	private void incrementSpeed() 
	{
		p5_knob_speed.setValue(p5_knob_speed.getValue() + speedknob_keystep); 
	}

	private void decrementSpeed() 
	{
		p5_knob_speed.setValue(p5_knob_speed.getValue() - speedknob_keystep); 
	}

	@Override
	public void paint(PGraphics pg)
	{
		pg.background(_BGCOLOR);
		super.paint(pg);
		pg.image(titleImage,265,740);
		pg.image(overlayImage,5,25);
	}

}
