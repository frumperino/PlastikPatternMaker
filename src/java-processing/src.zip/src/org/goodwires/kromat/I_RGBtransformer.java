package org.goodwires.kromat;

public interface I_RGBtransformer 
{

	/**
	 * Updates RGB transformer and white point adapter as necessary
	 * @param src
	 * @param dst
	 */
	void update();

	/**
	 * Transform single pixel with default fit mode
	 * @param source_RGB
	 * @return
	 */
	float[] transform_RGB(float[] source_RGB);

	/**
	 * Transform single pixel with selectable fit mode
	 * @param source_RGB - source colorspace RGB color triplet
	 * @param fitMode - fit mode
	 * @return - destination colorspace RGB color triplet
	 */
	float[] transform_RGB(float[] source_RGB, RGBfit.RGBfitMode fitMode);

	/**
	 * Transform single pixel with default fit mode
	 * @param source_RGB
	 * @param inBits
	 * @param outBits
	 * @return
	 */
	int[] transform_RGB(int[] source_RGB, int inBits, int outBits);

	/**
	 * Transform single pixel with selectable fit mode
	 * @param source_RGB - source pixel
	 * @param inBits - bit depth of source pixel
	 * @param outBits - bit depth of output pixel
	 * @param fitMode - fit mode
	 * @return - transformed pixel
	 */
	int[] transform_RGB(int[] source_RGB, int inBits, int outBits, RGBfit.RGBfitMode fitMode);

	/**
	 * Transform pixel array (image) with default fit mode
	 * @param source_RGB - source image
	 * @param inBits - bit depth of source image
	 * @param outBits - bit depth of output image
	 * @return - transformed image in output color space
	 */
	int[][] transform_RGB(int[][] source_RGB, int inBits, int outBits);

	/**
	 * Transform pixel array (image) with selectable fit mode
	 * @param source_RGB - source image
	 * @param inBits - bit depth of source image
	 * @param outBits - bit depth of output image
	 * @param fitMode - fit mode
	 * @return - transformed image in output color space
	 */
	int[][] transform_RGB(int[][] source_RGB, int inBits, int outBits, RGBfit.RGBfitMode fitMode);

}