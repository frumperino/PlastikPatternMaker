package org.goodwires.kromat;

/**
 * RGB fitting methods used to post-process XYZ to RGB color matrix transforms.
 * 
 * <p/>
 * If the source XYZ value defines an out-gamut color for the target colorspace,
 * the resulting RGB channel values won't conform to the 0..1 valid range, and
 * will instead have invalid off-scale low (negative) values or off-scale high
 * values (greater than 100%).
 * 
 * <p/>
 * sRGB for example is a much smaller color space than e.g. Adobe RGB.
 * Specifying a super-rich green color in Adobe RGB (0x00FF00), when converted
 * by linear transformation via XYZ to sRGB channel intensity values, we sure
 * enough get 100% green out, but instead of zeros we get negative values for
 * the red and blue channels.
 * 
 * <p/>
 * One way to interpret these invalid / negative values is to consider the
 * readout an equation - hypothetically you'd have to add that much of red and
 * blue (with sRGB primaries) to the source color, before the sRGB 0x00FF00
 * color value would look the same as the source to a human (CIE system)
 * observer.
 *
 * <p/>
 * This is obviously not a reasonable outlook for most situations where we have
 * no wish or way to affect the wider-gamut source color, but must instead just
 * try to represent it as accurately as possible within the smaller gamut of the
 * target color space. Thus, the RGB fitting methods provided here are various
 * ways to "fail gracefully" with different compromises taken.
 * 
 * <p/>
 * Instead of barfing up an invalid-value exception, we shall instead produce
 * the most faithful compromise representation for the impossible source color,
 * as a valid RGB channel value combination inside the target color space.
 * 
 * <p/>
 * Sonny Windstrup
 * 
 * @author SWI
 *
 */
public class RGBfit 
{
	/**
	 * Which of the provided fit methods shall be considered systemwide default
	 */
	public static RGBfitMode __DEFAULT_FITMODE = RGBfitMode.CLIP;
	
	public enum RGBfitMode 
	{
		/**
		 * Default - fastest - simply snips off values greater than 1 or smaller
		 * than 0. Usually provides acceptable performance and reasonable
		 * luminance and saturation values but tends to simply bunch out-gamut
		 * color values into the nearest chrominant vertices which for some
		 * applications may be perceptually undesirable behavior.
		 */
		CLIP, 
		
		/**
		 * Fits RGB values into 0..1 range by use of flexible scale function
		 * that normally is straight 0..1 to 0..1 but expands to accommodate
		 * off-scale highs and lows on all channels. Produces perceptually
		 * realistic hues even for super-saturated colors (negative channel
		 * values), but tends to exaggerate luminance in those cases.
		 */
		FLEX, 
		
		/**
		 * Averages RGB output of CLIP and FLEX methods for a simple compromise
		 * that is usually perceptually preferable to either. Computationally
		 * cheaper than HSVMIX.
		 */
		RGBMIX,
		
		/**
		 * This compromise conversion method is the perceptually most accurate
		 * but also computationally most expensive. It uses internally both CLIP
		 * and FLEX methods in parallel to produce two separate RGB intermediate
		 * products. These are both converted to HSV. The output is a HSV to RGB
		 * conversion with H from FLEX and S,V from CLIP.
		 */
		HSVMIX
	};
	
	public static float[] fit(float[] rgb, RGBfitMode mode)
	{
		switch(mode)
		{
			case FLEX: return fit_flex(rgb);
			case HSVMIX: return fit_hsvmix(rgb);
			case RGBMIX: return fit_rgbmix(rgb);
			case CLIP: return fit_clip(rgb);
			default:
			{
				return fit(rgb, __DEFAULT_FITMODE);
			}
		}
	}
	
	public static float[] fit_clip(float[] rgb)
	{
		float[] rgb_out = new float[3];
		for (int i=0;i<3;i++)
		{
			float c = rgb[i];
			rgb_out[i] = c < 0 ? 0 : c > 1 ? 1 : c;
		}
		return rgb_out;
	}
	

	public static float[] fit_flex(float[] rgb)
	{
		float vmin = min(rgb);
		float vmax = max(rgb);
		boolean osh = (vmax > 1);
		boolean osl = (vmin < 0);
		boolean osx = osh | osl;
		if (!osx)
		{
			return rgb; // passthru
		}
		else
		{
			float[] rgb_out = new float[3];
			float s0 = osl ? vmin : 0;
			float s1 = osh ? vmax : 1;
			float sd = 1 / (s1 - s0);
			for (int i=0;i<3;i++)
			{
				rgb_out[i] = (rgb[i] - s0) * sd;
			}
			return rgb_out;
		}
	}

	public static float[] fit_rgbmix(float[] rgb)
	{
		float[] rgb1 = fit_clip(rgb);
		float[] rgb2 = fit_flex(rgb);
		float[] rgb_out = new float[3];
		for (int i=0;i<3;i++)
		{
			rgb_out[i] = 0.5f * ( rgb1[i] + rgb2[i] );
		}
		return rgb_out;
	}
	
	public static float[] fit_hsvmix(float[] rgb)
	{
		float[] hsv1 = HSV.rgb2hsv(fit_clip(rgb));
		float[] hsv2 = HSV.rgb2hsv(fit_flex(rgb));
		return HSV.hsv2rgb(new float[]{hsv2[0],hsv1[1],hsv1[2]});
	}
	
	public static float max(float[] values) 
	{
		int nv = values.length;
		float vmax = values[0];
		for (int i=1;i<nv;i++)
		{
			if (values[i] > vmax)
			{
				vmax = values[i];
			}
		}
		return vmax;
	}

	public static float min(float[] values)
	{
		int nv = values.length;
		float vmin = values[0];
		for (int i=1;i<nv;i++)
		{
			if (values[i] < vmin)
			{
				vmin = values[i];
			}
		}
		return vmin;
	}
}
