package org.goodwires.kromat;

/**
 * Matrix math 
 * @author SWI
 *
 */
public class Matrix
{
	private float[][] data;
	private int _cols;
	public int cols() 
	{
		return _cols;
	}
	private int _rows;
	public int rows()
	{
		return _rows;
	}
	public Matrix(int numCols, int numRows)
	{
		_cols = numCols < 1 ? 1 : numCols;
		_rows = numRows < 1 ? 1 : numRows;
		data = new float[_cols][_rows];
		for (int i=0;i<_cols;i++)
		{
			data[i] = new float[_rows];
		}
	}
	
	public boolean loadColumn(int colIndex, float[] column)
	{
		if ((column.length == _rows) && (colIndex >= 0) && (colIndex < _cols))
		{
			data[colIndex] = column;
			return true;
		}
		return false;
	}
	

	public void set(int x, int y, float value)
	{
		if (isCoordinateValid(x,y))
		{
			data[x][y] = value;
		}
	}
	public float get(int x, int y)
	{
		if (isCoordinateValid(x, y))
		{
			return data[x][y];
		}
		return -1;
	}
	
	public void dump() 
	{
		for (int y=0;y<_rows;y++)
		{
			for (int x=0;x<_cols;x++)
			{
				System.out.print(get(x,y));
				if (x < (_cols-1))
				{
					System.out.print(", ");
				}
			}
			System.out.println();
		}
	}
	
	private boolean isCoordinateValid(int x, int y) 
	{
		return ((x >= 0) && (x < _cols) && (y >= 0) && (y < _rows));
	}
	
	public Matrix(float[][] columns)
	{
		this(columns.length,columns[0].length);
		loadColumns(columns);
	}
	
	public Matrix(float[] column)
	{
		this(1,column.length);
		data[0] = column;
	}
	
	public float[][] data()
	{
		return data;
	}
	
	private boolean loadColumns(float[][] columns) 
	{
		int v_cols = columns.length;
		int v_rows = columns[0].length;
		if ((v_cols == _cols) && (v_rows == _rows))
		{
			for (int x=0;x<v_cols;x++)
			{
				data[x] = columns[x];
			}
			return true;
		}
		return false;
	}
	
	private void swapRow(int a, int b) 
	{
		if ((a >= 0) && (b >= 0) && (a < _rows) && (b < _rows))
		{
			for (int x=0;x<_cols;x++)
			{
				float t = data[x][a];
				data[x][a] = data[x][b];
				data[x][b] = t;
			}
		}
	}

	public Matrix clone()
	{
		Matrix mc = new Matrix(_cols,_rows);
		for (int x=0;x<_cols;x++)
		{
			for (int y=0;y<_rows;y++)
			{
				mc.set(x, y, get(x,y));
			}
		}
		return mc;
	}
		
	public float[] getColumn(int x) 
	{
		if ((x >= 0) && (x < _cols))
		{
			return data[x];
		}
		return null;
	}
	
	public static Matrix multiply(Matrix A, Matrix B)
	{
		int mac = A.cols();
		int mar = A.rows();
		int mbc = B.cols();
		int mbr = B.rows();
		if (mbr == mac)
		{
			Matrix M = new Matrix(mbc,mar);
			// iterate through the output matrix columns
			for (int x=0;x<mbc;x++)
			{
				// iterate through the output matrix rows
				for (int y=0;y<mar;y++)
				{
					float sum = 0;
					for (int z=0;z<mac;z++)
					{
						sum += A.get(z,y) * B.get(x,z);
					}
					M.set(x,y,sum);
				}
			}
			return M;
		}
		// undefined - B rows != A columns
		return null;
	}
	
	// http://blog.acipo.com/matrix-inversion-in-javascript/
	// TODO: replace this thing with formal non-branching
	// method using cofactor and determinants.
	public static Matrix invert(Matrix m) 
	{
		if (m.cols() == m.rows()) // must be square
		{
			int size = m.cols();
			Matrix mc = m.clone(); 			   // copy of source matrix
			Matrix mi = new Matrix(size,size); // identity matrix
			for (int i=0;i<size;i++)
			{
				mi.set(i, i, 1); // populate diagonal of identity matrix
			}
			// row operations 
			for (int i=0;i<size;i++)
			{
				// diagonal element 
				float e = mc.get(i, i);
				if (e == 0)
				{
					// zero on the diagonal
					// search every row below 
					for (int ii=i+1;ii<size;ii++)
					{
						if (mc.get(i,ii) != 0)
						{
							// not zero
							// swap it
							mc.swapRow(i,ii);
							mi.swapRow(i,ii);
							break;
						}
					}
					// get new diagonal
					e = mc.get(i, i);
					if (e == 0)
					{
						// still zero!
						// cannot invert with this method
						return null;
					}
				}
				
				// scale by e - diagonal should now have 1
				for (int j=0;j<size;j++)
				{
					mc.set(j,i,mc.get(j,i) / e);
					mi.set(j,i,mi.get(j,i) / e);
				}
				
				// subtract row from all other rows
				for (int ii=0;ii<size;ii++)
				{
					if (ii == i)
					{
						continue;
					}
					e = mc.get(i, ii);
					
					for (int j=0;j<size;j++)
					{
						mc.set(j, ii, mc.get(j, ii) - e * mc.get(j, i));
						mi.set(j, ii, mi.get(j, ii) - e * mi.get(j, i));
					}
				}
			}
			return mi; // identity matrix should now contain inverse matrix
		}
		// wasn't square
		return null;
	}
}


