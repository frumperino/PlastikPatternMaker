package org.goodwires.kromat;

/**
 * Static helper functions for HSV --> RGB and RGB --> HSV color conversion.
 * All functions use normalized 0..1f channel values.
 * @author SWI
 *
 */
public class HSV 
{
	public static float[] hsv2rgb(float[] hsv)
	{
		if (hsv.length != 3) return null;
		
		float h = hsv[0];
		float s = hsv[1];
		float v = hsv[2];
		float r = 0;
		float g = 0;
		float b = 0;
		
		float h6 = h * 6;
		int st = (int) Math.floor(h6);	// quadrant
		float sv = h6 - st;				// phase
		float LE = v;					// lightest
		float LC = (1-s) * v;			// darkest
		float LD = sv * (v - LC);		// variable
		
		switch(st)
		{
			case 0: // red to yellow
			case 6: 
			{
	 			r = LE;
				g = LC+LD;
				b = LC;
			} break;
			case 1: // yellow to green
			{
				r = LE-LD;
				g = LE;
				b = LC;
			} break;
			case 2: // green to cyan
			{
				r = LC;
				g = LE;
				b = LC+LD;
			} break;
			case 3: // cyan to blue
			{
				r = LC;
				g = LE-LD;
				b = LE;
			} break;
			case 4: // blue to magenta
			{
				r = LC+LD;
				g = LC;
				b = LE;
			} break;
			case 5: // magenta to red
			{
				r = LE;
				g = LC;
				b = LE-LD;
			} break;
		}
		
		return new float[]{r,g,b};
	}
	
	// https://gist.github.com/mjackson/5311256
	public static float[] rgb2hsv(float[] rgb)
	{
		if (rgb.length != 3) return null;
		
		float vmax = RGBfit.max(rgb);
		float vmin = RGBfit.min(rgb);
		float d = vmax - vmin;
		float s = (vmax == 0 ? 0 : d / vmax);
		float v = vmax;
		
		float h = 0;
		if (vmax > vmin)
		{
			float r = rgb[0];
			float g = rgb[1];
			float b = rgb[2];
			int maxi = maxi(rgb);
			switch(maxi)
			{
				case 0: // red is brightest
				{
					h = (g - b) + d * (g < b ? 6 : 0); 
					h /= 6 * d;
				} break;
				case 1: // green
				{
					h = (b - r) + d * 2; 
					h /= 6 * d; 
				} break;
				case 2: // blue
				{
					h = (r - g) + d * 4;
					h /= 6 * d;
				} break;
			}
		}
		
		return new float[]{h,s,v};
	}

	/**
	 * Find highest index of provided value set
	 * @param values
	 * @return
	 */
	private static int maxi(float[] values) 
	{
		int idx = 0;
		int nv = values.length;
		float vmax = values[0];
		for (int i=1;i<nv;i++)
		{
			if (values[i] > vmax)
			{
				vmax = values[i];
				idx = i;
			}
		}
		return idx;
	}
}
