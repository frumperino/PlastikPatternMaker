package org.goodwires.kromat;

public interface I_colorSpace
{
	/**
	 * Colorspace-native channel set from CIE XYZ triplet
	 * @param cie_XYZ
	 * @return
	 */
	float[] fromXYZ(float[] cie_XYZ);

	/**
	 * Convert colorspace-native channel set to CIE XYZ triplet
	 * @param values
	 * @return
	 */
	float[] toXYZ(float[] values);

	/**
	 * @return - number of native colorspace channels
	 */
	int numChannels();
	
	/**
	 * Obtain CIE xy(Y) chromaticity coordinates of selected primary / colorspace vertex
	 * @param channel 
	 * @return
	 */
	public float[] getPrimary_xyY(int channel);
	
	/**
	 * Obtain white reference
	 * @return
	 */
	float[] getWhiteReferenceXYZ();

}
