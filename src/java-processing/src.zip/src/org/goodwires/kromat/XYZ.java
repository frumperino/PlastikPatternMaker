package org.goodwires.kromat;

/**
 * Static helper functions for XYZ / xyY conversion
 * @author SWI
 *
 */
public class XYZ 
{
	// http://www.brucelindbloom.com/index.html?Eqn_XYZ_to_xyY.html
	public static float[] XYZ_2_xyY(float[] XYZ)
	{
		if (XYZ.length == 3)
		{
			float X = XYZ[0];
			float Y = XYZ[1];
			float Z = XYZ[2];
			if (!((X == 0) && (Y == 0) && (Z == 0)))
			{
				float x = X / (X+Y+Z);
				float y = Y / (X+Y+Z);
				return new float[]{x,y,Y};
			}
		}
		return new float[]{0,0,0}; 
		// invalid value - substitute xy with chromaticity coordinates of colorspace whitepoint
	}
	
	// http://www.brucelindbloom.com/index.html?Eqn_XYZ_to_xyY.html
	public static float[] xyY_2_XYZ(float[] xyY)
	{
		if (xyY.length == 3)
		{
			float x = xyY[0];
			float y = xyY[1];
			float Y = xyY[2];
			if (y != 0)
			{
				float X = x*Y / y;
				float Z = (1 - x - y) * Y / y;
				return new float[]{X,Y,Z};
			}
		}
		return new float[]{0,0,0};
	}
}
