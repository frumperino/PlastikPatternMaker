package org.goodwires.kromat;

import org.goodwires.kromat.RGBfit.RGBfitMode;

public interface I_colorSpace_RGB extends I_colorSpace
{

	/**
	 * Convert RGB color in this colorspace to CIE XYZ values. 
	 * @param rgb - floating point RGB colors normalized to 0...1f ranges.
	 * @return - XYZ values nominally 0..1f but may exceed this range in some color spaces.
	 */
	float[] convert_RGB2XYZ(float[] rgb);

	float[] convert_RGB2XYZ(int[] rgb, int bits);

	float[] convert_RGB2XYZ(int rgb24);
	
	float[] convert_XYZ2RGB(float[] xyz);

	float[] convert_XYZ2RGB(float[] xyz, RGBfitMode fitMode);

	int[] convert_XYZ2RGB(float[] xyz, int bits);

	int[] convert_XYZ2RGB(float[] xyz, int bits, RGBfit.RGBfitMode fitMode);

	Matrix getMatrix_XYZ2RGB();

	Matrix getMatrix_RGB2XYZ();

	/**
	 * (re)compute colorspace matrices. 
	 */
	void compute();

}