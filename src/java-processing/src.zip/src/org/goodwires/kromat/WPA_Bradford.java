package org.goodwires.kromat;

/**
 * Bradford-type Chromatic White point Adaptation filter
 * @author SWI
 *
 */
public class WPA_Bradford 
{
	Matrix mCA;
	
	public WPA_Bradford(float[] src_wp_XYZ, float[] dest_wp_XYZ)
	{
		// Bradford cone response definition
		// http://www.brucelindbloom.com/index.html?Eqn_RGB_XYZ_Matrix.html
		Matrix mAf = new Matrix(new float[][]{
			{0.8951f,-0.7502f,0.0389f},
			{0.2664f,1.7135f,-0.0685f},
			{-0.1614f,0.0367f,1.0296f}
			});
		Matrix mAr = Matrix.invert(mAf);		// Bradford cone response matrix inverted
		Matrix wpS = new Matrix(src_wp_XYZ);	// source white point XYZ
		Matrix wpD = new Matrix(dest_wp_XYZ);	// destination white point XYZ
		Matrix crS = Matrix.multiply(mAf, wpS); // cone response transform coefficients for source 
		Matrix crD = Matrix.multiply(mAf, wpD); // cone response transform coefficients for destination
		Matrix t = new Matrix(new float[][]{
			{crD.get(0, 0) / crS.get(0, 0),0,0},
			{0,crD.get(0, 1) / crS.get(0, 1),0},
			{0,0,crD.get(0, 2) / crS.get(0, 2)}
			});					
		mCA = Matrix.multiply(mAr,Matrix.multiply(t, mAf));	// final linear transform matrix 
	}
	
	/**
	 * @param src_XYZ - source XYZ value
	 * @return - destination XYZ value with white point adaptation applied
	 */
	public float[] XYZ_convert(float[] src_XYZ)
	{
		return Matrix.multiply(mCA, new Matrix(src_XYZ)).getColumn(0);
	}
}
