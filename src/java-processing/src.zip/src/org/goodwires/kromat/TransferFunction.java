package org.goodwires.kromat;

import org.goodwires.kromat.tf.*;

/**
 * Transfer function for use with compression or decompression of colorspace
 * channel values; the "gamma" curve of sRGB being one example.
 * 
 * @author SWI
 *
 */
public abstract class TransferFunction
{
	/**
	 * Compressed to Linear
	 * @param compressed
	 * @return linear
	 */
	public abstract float toLinear(float compressed);
	
	/**
	 * Linear to Compressed
	 * @param linear
	 * @return compressed
	 */
	public abstract float toCompressed(float linear);
	
	/**
	 * Compressed to linear, multi channel
	 * @param compressed
	 * @return
	 */
	public float[] toLinear(float[] compressed)
	{
		int nc = compressed.length;
		float[] o = new float[nc];
		for (int i=0;i<nc;i++)
		{
			o[i] = toLinear(compressed[i]);
		}
		return o;
	}
	
	/**
	 * Compressed to linear, Multi-channel, multi-cell / pixel
	 * @param compressed
	 * @return
	 */
	public float[][] toLinear(float[][] compressed)
	{
		int x = compressed.length;
		int y = compressed[0].length;
		float[][] o = new float[x][y];
		for (int i=0;i<x;i++)
		{
			o[i] = toLinear(compressed[i]);
		}
		return o;
	}
	
	/**
	 * Linear to compressed (multi-channel)
	 * @param linear
	 * @return
	 */
	public float[] toCompressed(float[] linear)
	{
		int nc = linear.length;
		float[] o = new float[nc];
		for (int i=0;i<nc;i++)
		{
			o[i] = toCompressed(linear[i]);
		}
		return o;
	}
	
	/**
	 * Linear to compressed (multi-channel, multi-cell/pixel)
	 * @param linear
	 * @return
	 */
	public float[][] toCompressed(float[][] linear)
	{
		int x = linear.length;
		int y = linear[0].length;
		float[][] o = new float[x][y];
		for (int i=0;i<x;i++)
		{
			o[i] = toCompressed(linear[i]);
		}
		return o;
	}
	
	// ===================================================================================
	// Static transfer function factory
	// ===================================================================================
	
	/**
	 * @return - linear transfer function 
	 */
	public static TransferFunction linear()
	{
		return new TF_linear();
	}

	/**
	 * Continuous, logarithmic transfer function
	 * @param exponent 
	 * @return - logarithmic transfer function with selected exponent
	 */
	public static TransferFunction log(float exponent) 
	{
		return new TF_log(exponent);
	}

	/**
	 * Discontinuous, parametric transfer function
	 * f(x) = { x < d ? cx : (ax+b)^y } 
	 * used for sRGB, iRGB, ProPhoto RGB among others
	 * @param gamma - exponent for log part of curve
	 * @param a 
	 * @param b
	 * @param c
	 * @param d
	 * @return generated transfer function
	 */
	public static TransferFunction yabcd(float gamma, float a, float b, float c, float d)
	{
		return new TF_yabcd(gamma, a, b, c, d);
	}
	
	/**
	 * @return - classic sRGB transfer function roughly analogous to log 2.2
	 */
	public static TransferFunction sRGB()
	{
		return yabcd(2.4f, 0.947867f, 0.052133f, 0.077399f, 0.040450f);
	}
	
	/**
	 * @return - iRGB transfer function roughly analogous to log 1.8
	 * Specification 2017-07 (SWI)
	 */
	public static TransferFunction iRGB()
	{
		return yabcd(1.800000f, 0.952381f, 0.047619f, 0.299555f, 0.040450f);
	}
	
	/**
	 * @return AdobeRGB-specific log transfer function (2.09375, or 536/256 exactly)
	 */
	public static TransferFunction adobeRGB()
	{
		return new TF_log(536f/256f);
	}
	
	/**
	 * Get transfer function by name 
	 * @param tf
	 * @return
	 */
	public static TransferFunction getByName(String tf)
	{
		String name = tf.trim().toLowerCase();
		if (name.equals("srgb")) return sRGB();
		if (name.equals("linear")) return linear();
		if (name.equals("adobeRGB")) return adobeRGB();
		return sRGB();
	}

}
