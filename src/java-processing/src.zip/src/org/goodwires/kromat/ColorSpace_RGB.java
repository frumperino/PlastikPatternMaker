package org.goodwires.kromat;

import org.goodwires.kromat.RGBfit.RGBfitMode;
import org.goodwires.kromat.cs.CS_WS2812;
import org.goodwires.kromat.cs.CS_sRGB_linear;

/**
 * KROMAT RGB 3-channel color space
 * @author SWI
 *
 */
public class ColorSpace_RGB extends ColorSpace implements I_colorSpace_RGB
{
	// whitepoint / reference white (XYZ)
	private Matrix XYZ2RGB;
	private Matrix RGB2XYZ;
	
	private float[] bsmf; // bitscale constants
	
	public ColorSpace_RGB(String name) 
	{
		super(3, name);
		generateBitscaleConstants();
	}

	private void generateBitscaleConstants() 
	{
		bsmf = new float[17];
		for (int i=1;i<17;i++)
		{
			bsmf[i] = 1f / ((1 << i) - 1);
		}
	}

	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#convert_RGB2XYZ(float[])
	 */
	@Override
	public float[] convert_RGB2XYZ(float[] rgb)
	{
		if (rgb.length == 3)
		{
			Matrix mRGB = new Matrix(tf.toLinear(rgb));
			Matrix mXYZ = Matrix.multiply(RGB2XYZ, mRGB);
			return mXYZ.getColumn(0);
		}
		return null; // wrong number of channels
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#convert_RGB2XYZ(int[], int)
	 */
	@Override
	public float[] convert_RGB2XYZ(int[] rgb, int bits)
	{
		if ((rgb.length == 3) && (bits > 1) && (bits < 17))
		{
			float m = bsmf[bits];
			float r = m * rgb[0];
			float g = m * rgb[1];
			float b = m * rgb[2];
			return convert_RGB2XYZ(new float[]{r,g,b});
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * @see org.goodwires.kromat.I_colorSpace_RGB#convert_RGB2XYZ(int)
	 */
	@Override
	public float[] convert_RGB2XYZ(int rgb24)
	{
		return convert_RGB2XYZ(expand_rgb24(rgb24), 8);
	}

	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#convert_XYZ2RGB(float[])
	 */
	@Override
	public float[] convert_XYZ2RGB(float[] xyz)
	{
		return convert_XYZ2RGB(xyz, RGBfit.__DEFAULT_FITMODE);
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#convert_XYZ2RGB(float[], com.gws.swi.color.kromat.RGBfit.RGBfitMode)
	 */
	@Override
	public float[] convert_XYZ2RGB(float[] xyz, RGBfitMode fitMode)
	{
		if (xyz.length == 3)
		{
			Matrix mXYZ = new Matrix(xyz);
			float[] rgb= Matrix.multiply(XYZ2RGB,mXYZ).getColumn(0);
			if (range_exceeded(rgb,0,1))
			{
				return tf.toCompressed(RGBfit.fit(rgb, fitMode));
			}
			return tf.toCompressed(rgb);
		}
		return null; // wrong number of source channels
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#convert_XYZ2RGB(float[], int)
	 */
	@Override
	public int[] convert_XYZ2RGB(float[] xyz, int bits)
	{
		return convert_XYZ2RGB(xyz, bits, RGBfit.__DEFAULT_FITMODE);
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#convert_XYZ2RGB(float[], int, com.gws.swi.color.kromat.RGBfit.RGBfitMode)
	 */
	@Override
	public int[] convert_XYZ2RGB(float[] xyz, int bits, RGBfit.RGBfitMode fitMode)
	{
		if ((xyz.length == 3) && (bits > 1) && (bits < 17))
		{
			float[] rgb = convert_XYZ2RGB(xyz, fitMode);
			float m = (1 << bits) - 1;
			int r = (int) Math.round(m * rgb[0]);
			int g = (int) Math.round(m * rgb[1]);
			int b = (int) Math.round(m * rgb[2]);
			return new int[]{r,g,b};
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#getMatrix_XYZ2RGB()
	 */
	@Override
	public Matrix getMatrix_XYZ2RGB()
	{
		return XYZ2RGB;
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#getMatrix_RGB2XYZ()
	 */
	@Override
	public Matrix getMatrix_RGB2XYZ()
	{
		return RGB2XYZ;
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_colorSpace_RGB#compute()
	 */
	@Override
	public void compute() 
	{
		// http://www.brucelindbloom.com/index.html?Eqn_RGB_XYZ_Matrix.html
		int nc = numch;
		Matrix m1 = new Matrix(numch,3);
		for (int i=0;i<nc;i++)
		{
			float xc = cc_xyY[i][0];
			float yc = cc_xyY[i][1];
			m1.set(i, 0, xc/yc);
			m1.set(i, 1, 1);
			m1.set(i, 2, (1-xc-yc) / yc);
		}
		Matrix m2 = Matrix.invert(m1);
		Matrix mW = new Matrix(refwhite_XYZ);
		Matrix mS = Matrix.multiply(m2, mW);
		RGB2XYZ = new Matrix(numch,3);
		for (int y=0;y<3;y++)
		{
			for (int x=0;x<numch;x++)
			{
				float s = mS.get(0,x);
				float xyz = m1.get(x, y);
				RGB2XYZ.set(x, y, s * xyz);
			}
		}
		for (int i=0;i<numch;i++)
		{
			cc_xyY[i][2] = RGB2XYZ.get(i, 1);
		}
		XYZ2RGB = Matrix.invert(RGB2XYZ);
	}

	/**
	 * @param channels - channel values to be evaluated
	 * @param rangeMin - lowest permitted value
	 * @param rangeMax - highest permitted value
	 * @return - true if any channel value is off-scale low or off-scale high 
	 */
	private boolean range_exceeded(float[] channels, float rangeMin, float rangeMax) 
	{
		for (int i=0;i<channels.length;i++)
		{
		  if (channels[i] < rangeMin) return true;
		  if (channels[i] > rangeMax) return true;
		}
		return false;
	}

	@Override
	public float[] fromXYZ(float[] cie_XYZ) 
	{
		return convert_XYZ2RGB(cie_XYZ);
	}

	@Override
	public float[] toXYZ(float[] rgbvalues)
	{
		return convert_RGB2XYZ(rgbvalues);
	}
	
	public static int[] expand_rgb24(int rgb) 
	{
		int[] r = new int[3];
		r[0] = (rgb >> 16) & 0xFF;
		r[1] = (rgb >> 8) & 0xFF;
		r[2] = rgb & 0xFF;
		return r;
	}

	public static ColorSpace_RGB getByName(String csName) 
	{ 
		String name = csName.trim().toLowerCase();
		if (name.equals("srgb")) return sRGB();
		if (name.equals("srgb_linear")) return new CS_sRGB_linear();
		if (name.equals("adobergb")) return adobeRGB();
		if (name.equals("irgb")) return iRGB();
		if (name.equals("ws2812")) return new CS_WS2812();
		return sRGB();
	}

	public TransferFunction getTransferFunction() 
	{
		return this.tf;
	}
	
}
