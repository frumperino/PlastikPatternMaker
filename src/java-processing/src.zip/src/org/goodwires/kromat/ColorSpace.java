package org.goodwires.kromat;

import org.goodwires.kromat.cs.*;

/**
 * KROMAT colorspace abstract base class
 * Most applications will want to use 
 * @author SWI
 *
 */
public abstract class ColorSpace implements I_colorSpace
{
	protected String name;
	protected int numch;
	protected TransferFunction tf = TransferFunction.linear();
	
	/**
	 * Colorspace reference white (for emissive display types same as white point)
	 */
	protected float[] refwhite_XYZ = Illuminant.D65().XYZ();
	
	/**
	 * Colorspace channel chrominants (x,y,Y)
	 */
	protected float[][] cc_xyY;

	@Override
	public int numChannels()
	{
		return numch;
	}
	
	public String name()
	{
		return name;
	}
	
	public ColorSpace(int numChannels, String name)
	{
		this.numch = numChannels;
		this.name = name;
		cc_xyY = new float[this.numch][3];
	}
	
	protected void setReferenceWhite_XYZ(float[] cie_XYZ)
	{
		if (cie_XYZ.length == 3)
		{
			refwhite_XYZ = new float[]
					{
						cie_XYZ[0] / cie_XYZ[1],
						1f,
						cie_XYZ[2] / cie_XYZ[1]
					};
		}
	}
	
	/**
	 * Most colorspaces have a nonlinear function providing a pseudo-logarithmic
	 * "gamma compression" transformation of linear color channel values to
	 * representational bit-scale values (e.g. sRGB's 8-bit hex triplet)
	 * 
	 * Typical instance references to transfer functions can be obtained from the TransferFunction class.
	 * 
	 * @param transferFunction
	 */
	protected void setTransferFunction(TransferFunction transferFunction) 
	{
		tf = transferFunction;
	}

	/**
	 * Set chromaticity coordinates of chrominant channel
	 * @param channel - index of channel, e.g. R = 0, G = 1, B = 2
	 * @param cie_xy - CIE xy coordinate of chrominant
	 */
	protected void setPrimary_xy(int channel, float[] cie_xy) 
	{
		if ((channel >= 0) && (channel < numch) && (cie_xy != null) && (cie_xy.length > 1))
		{
			cc_xyY[channel][0] = cie_xy[0];
			cc_xyY[channel][1] = cie_xy[1];
			// Y value computed as part of matrix math
		}
	}
	
	/**
	 * @param channel - channel index
	 * @return - CIE xyY chromaticity coordinates of channel's primary
	 */
	@Override
	public float[] getPrimary_xyY(int channel)
	{
		if ((channel >= 0) && (channel < numch))
		{
			return cc_xyY[channel];
		}
		return null;
	}
	
	/**
	 * Get CIE XYZ coordinates of colorspace reference white 
	 * @return
	 */
	@Override
	public float[] getWhiteReferenceXYZ() 
	{
		return refwhite_XYZ;
	}

	/**
	 * Convert to colorspace-native color values from CIE XYZ values.
	 * @param cie_XYZ - CIE XYZ values
	 * @return - native colorspace values (0..1f) 
	 */
	public abstract float[] fromXYZ(float[] cie_XYZ);
	
	/**
	 * Convert colorspace-native color values to CIE XYZ values
	 * @param values - native colorspace values (0..1f / channel) 
	 * @return - CIE XYZ values.
	 */
	public abstract float[] toXYZ(float[] values);
	
	public static ColorSpace_RGB iRGB()
	{
		return new CS_iRGB();
	}
	
	public static ColorSpace_RGB sRGB()
	{
		return new CS_sRGB();
	}
	
	public static ColorSpace_RGB adobeRGB()
	{
		return new CS_AdobeRGB();
	}
	
	public static ColorSpace getByName(String csName) 
	{ 
		String name = csName.trim().toLowerCase();
		if (name.equals("srgb")) return sRGB();
		if (name.equals("srgb_linear")) return new CS_sRGB_linear();
		if (name.equals("adobergb")) return adobeRGB();
		if (name.equals("irgb")) return iRGB();
		if (name.equals("ws2812")) return new CS_WS2812();
		return sRGB();
	}
	
}
