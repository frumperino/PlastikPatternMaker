package org.goodwires.kromat;

/**
 * Kromat service - performs unidirectional RGB color transformation between a
 * source and a destination color space; for example from PC-standard sRGB to a
 * device-specific LED color space, or the device-independent iRGB
 * wide-gamut LED colorspace.
 * 
 * @author SWI
 *
 */
public class RGBtransformer implements I_RGBtransformer
{
	/**
	 * The maximum permitted combined absolute deviation between source and
	 * destination colorspace white-reference XYZ coordinates before white point
	 * adapter shall be used in conversion.
	 */
	private static final float __whitePointDeltaThreshold = 0.001f;

	/**
	 * Source color space
	 */
	private I_colorSpace_RGB _cs_src;
	
	/**
	 * Destination color space
	 */
	private I_colorSpace_RGB _cs_dst;
	
	/**
	 * Optionally instantiated Bradford-type white point adapter
	 */
	private WPA_Bradford _wpa = null;
	
	/**
	 * True if white point adapter is in use
	 */
	private boolean _use_wpa = false;

	/**
	 * Instantiate RGB color transformer 
	 * @param src - source color space
	 * @param dst - destination color space
	 * @param fitMode - 
	 */
	public RGBtransformer(I_colorSpace_RGB src, I_colorSpace_RGB dst)
	{
		_cs_src = src;
		_cs_dst = dst;
		update();
	}

	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#update()
	 */
	@Override
	public void update() 
	{
		float[] src_wp = _cs_src.getWhiteReferenceXYZ();
		float[] dst_wp = _cs_dst.getWhiteReferenceXYZ();
		if (!compareWhiteRef(src_wp,dst_wp,__whitePointDeltaThreshold))
		{
			// white reference mismatch
			// so instantiate Bradford-type white point adapter
			_wpa = new WPA_Bradford(src_wp,dst_wp);
			_use_wpa = true;
		}
	}
	
	/**
	 * @param wr1_xyz
	 * @param wr2_xyz
	 * @param threshold
	 * @return - returns true if all white reference channel deltas between the
	 *         source and destination colorspaces are below specified threshold
	 */
	boolean compareWhiteRef(float[] wr1_xyz, float[] wr2_xyz, float threshold)
	{
		for (int i=0;i<3;i++)
		{
			if (Math.abs(wr1_xyz[i] - wr2_xyz[i]) > threshold) return false;
		}
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#transform_RGB(float[])
	 */
	@Override
	public float[] transform_RGB(float[] source_RGB) 
	{
		return transform_RGB(source_RGB, RGBfit.__DEFAULT_FITMODE);
	}

	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#transform_RGB(float[], com.gws.swi.color.kromat.RGBfit.RGBfitMode)
	 */
	@Override
	public float[] transform_RGB(float[] source_RGB, RGBfit.RGBfitMode fitMode)
	{
		float[] src_XYZ = _cs_src.convert_RGB2XYZ(source_RGB);
		if (_use_wpa)
		{
			// use white point adapter to compute destination XYZ value
			float[] dst_XYZ = _wpa.XYZ_convert(src_XYZ);
			return _cs_dst.convert_XYZ2RGB(dst_XYZ, fitMode);
		}
		else
		{
			// proceed using source XYZ values (same white point)
			return _cs_dst.convert_XYZ2RGB(src_XYZ, fitMode);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#transform_RGB(int[], int, int)
	 */
	@Override
	public int[] transform_RGB(int[] source_RGB, int inBits, int outBits)
	{
		return transform_RGB(source_RGB, inBits, outBits, RGBfit.__DEFAULT_FITMODE);
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#transform_RGB(int[], int, int, com.gws.swi.color.kromat.RGBfit.RGBfitMode)
	 */
	@Override
	public int[] transform_RGB(int[] source_RGB, int inBits, int outBits, RGBfit.RGBfitMode fitMode)
	{
		float[] src_XYZ = _cs_src.convert_RGB2XYZ(source_RGB, inBits);
		if (_use_wpa)
		{
			// use white point adapter to compute destination XYZ value
			float[] dst_XYZ = _wpa.XYZ_convert(src_XYZ);
			return _cs_dst.convert_XYZ2RGB(dst_XYZ, outBits, fitMode);
		}
		else
		{
			// proceed using source XYZ values (same white point)
			return _cs_dst.convert_XYZ2RGB(src_XYZ, outBits, fitMode);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#transform_RGB(int[][], int, int)
	 */
	@Override
	public int[][] transform_RGB(int[][] source_RGB, int inBits, int outBits)
	{
		return transform_RGB(source_RGB, inBits, outBits, RGBfit.__DEFAULT_FITMODE);
	}
	
	/* (non-Javadoc)
	 * @see com.gws.swi.color.kromat.I_RGBtransformer#transform_RGB(int[][], int, int, com.gws.swi.color.kromat.RGBfit.RGBfitMode)
	 */
	@Override
	public int[][] transform_RGB(int[][] source_RGB, int inBits, int outBits, RGBfit.RGBfitMode fitMode)
	{
		int np = source_RGB.length;
		int[][] o = new int[np][3];
		for (int i=0;i<np;i++)
		{
			o[i] = transform_RGB(source_RGB[i], inBits, outBits, fitMode);
		}
		return o;
	}


}
