package org.goodwires.kromat;

public class Illuminant 
{
	float X,Y,Z;
	
	float x,y;
	
	String name;
	
	// constructors
	
	public Illuminant(String name, float wp_X, float wp_Y, float wp_Z)
	{
		this.name = name;
		float scale = 1f / wp_Y;
		this.X = scale * wp_X;
		this.Y = scale * wp_Y;
		this.Z = scale * wp_Z;
		float[] xyY = XYZ.XYZ_2_xyY(new float[]{wp_X,wp_Y,wp_Z});
		this.x = xyY[0];
		this.y = xyY[1];
	}
	
	public Illuminant(String name, float wp_x, float wp_y)
	{
		this.name = name;
		float[] xyz = XYZ.xyY_2_XYZ(new float[]{wp_x,wp_y,1f});
		this.X = xyz[0];
		this.Y = 1f;
		this.Z = xyz[2];
		this.x = wp_x;
		this.y = wp_y;
	}
	
	/**
	 * Return tristimulus CIE XYZ values for illuminant (normalized so Y = 1)
	 * @return
	 */
	public float[] XYZ()
	{
		return new float[]{X,Y,Z};
	}
	
	/**
	 * Return CIE xy chromaticity coordinates for illuminant
	 * @return
	 */
	public float[] xyY()
	{
		return new float[]{x,y,1};
	}
	
	/**
	 * Return name of this illuminant
	 * @return
	 */
	public String name()
	{
		return this.name;
	}
	
	// ----------------------------------------------------------
	// Static factory methods
	
	/**
	 * @return standard CIE Illuminant D75 (~CCT 7504)
	 * <br/>
	 * Source: https://en.wikipedia.org/wiki/Standard_illuminant#White_points_of_standard_illuminants
	 */
	public static Illuminant D75()
	{
		return new Illuminant("D75", 0.29902f, 0.31485f);
	}

	/**
	 * @return standard CIE Illuminant D65 (~CCT 6504)
	 * <br/>
	 * Source: https://en.wikipedia.org/wiki/Standard_illuminant#White_points_of_standard_illuminants
	 */
	public static Illuminant D65()
	{
		return new Illuminant("D65", 0.31271f, 0.32902f);
	}
	
	/**
	 * D60 is not listed in the D-series wikipedia article. The coordinates are
	 * instead found in the ACES article: source:
	 * https://en.wikipedia.org/wiki/Academy_Color_Encoding_System
	 */
	public static Illuminant D60() 
	{
		return new Illuminant("D60", 0.32168f, 0.33767f);
	}

	/**
	 * @return standard CIE Illuminant D55 (~CCT 5503K)
	 * <br/>
	 * Source: https://en.wikipedia.org/wiki/Standard_illuminant#White_points_of_standard_illuminants
	 */
	public static Illuminant D55()
	{
		return new Illuminant("D55", 0.33242f, 0.34743f);
	}

	/**
	 * @return standard CIE Illuminant D50 (~CCT 5003K)
	 * <br/>
	 * Source: https://en.wikipedia.org/wiki/Standard_illuminant#White_points_of_standard_illuminants
	 */
	public static Illuminant D50()
	{
		return new Illuminant("D50", 0.34567f, 0.35850f);
	}
	
	/**
	 * @return standard CIE illuminant A (Incandescent / tungsten - ~CCT 2856K)
	 * <br/>
	 * Source: https://en.wikipedia.org/wiki/Standard_illuminant#White_points_of_standard_illuminants
	 */
	public static Illuminant A()
	{
		return new Illuminant("A", 0.44757f, 0.40745f);
	}

	
}
