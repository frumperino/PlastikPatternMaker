package org.goodwires.kromat.tf;

import org.goodwires.kromat.TransferFunction;

/**
 * Continuous logarithmic transfer function (used with Adobe RGB)
 * @author SWI
 *
 */
public class TF_log extends TransferFunction
{
	private static final float _minExp = 0.01f;
	private float _exp;
	private float _invex;

	public TF_log(float exponent) 
	{
		_exp = exponent > _minExp ? exponent : _minExp;
		_invex = 1 / _exp;
	}
	
	@Override
	public float toLinear(float compressed) 
	{
		return (float) Math.pow(compressed, _exp);
	}

	@Override
	public float toCompressed(float linear) 
	{
		return (float) Math.pow(linear, _invex);
	}

}
