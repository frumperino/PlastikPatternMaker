package org.goodwires.kromat.tf;

import org.goodwires.kromat.TransferFunction;

/**
 * Transfer function template 
 * f(x) = { x < d ? cx : (ax+b)^y }
 * used for sRGB, iRGB, ProPhoto RGB etc
 * @author SWI
 *
 */
public class TF_yabcd extends TransferFunction 
{
	private float _gamma;
	private float _a;
	private float _b;
	private float _c;
	private float _d;
	
	private float _p;
	private float _q;
	private float _r;
	private float _s;
	private float _t;

	public TF_yabcd(float gamma, float a, float b, float c, float d) 
	{
		setConstants(new float[]{gamma,a,b,c,d});
	}

	@Override
	public float toLinear(float compressed) 
	{
		if (compressed < _d)
		{
			return _c * compressed;
		}
		else
		{
			return (float) Math.pow(_a * compressed + _b, _gamma);
		}
	}

	@Override
	public float toCompressed(float linear) 
	{
		if (linear < _t)
		{
			return _s * linear;
		}
		else
		{
			return (float) (_q * Math.pow(linear, _p) - _r);
		}
	}
	
	/**
	 * Obtain currently used parametric curve constants
	 * f(x) = { x < d ? cx : (ax+b)^y }
	 * @return float array with {y,a,b,c,d}
	 */
	public float[] getConstants()
	{
		return new float[]{_gamma,_a,_b,_c,_d};
	}
	
	/**
	 * Set parametric curve constants
	 * f(x) = { x < d ? cx : (ax+b)^y }
	 * @param yabcd - float array with {y,a,b,c,d}
	 */
	public void setConstants(float[] yabcd)
	{
		if (yabcd.length == 5)
		{
			_gamma = yabcd[0];
			_a = yabcd[1];
			_b = yabcd[2];
			_c = yabcd[3];
			_d = yabcd[4];
			
			_p = 1/_gamma;
			_q = 1/_a;
			_r = _q-1;
			_s = 1/_c;
			_t = _c*_d;
		}
	}
	
	public void makeLinear()
	{
		//                       y a b c d
		setConstants(new float[]{1,1,0,1,1});
	}
	
	public void makeLogarithmic(float exponent)
	{
		//                              y a b c d
		setConstants(new float[]{exponent,1,0,1,0});
	}

}
