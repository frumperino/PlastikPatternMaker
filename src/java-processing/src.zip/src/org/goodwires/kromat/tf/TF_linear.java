package org.goodwires.kromat.tf;

import org.goodwires.kromat.TransferFunction;

public class TF_linear extends TransferFunction {

	@Override
	public float toLinear(float compressed)
	{
		return compressed;
	}

	@Override
	public float toCompressed(float linear) 
	{
		return linear;
	}

}
