package org.goodwires.kromat.cs;

import org.goodwires.kromat.ColorSpace_RGB;
import org.goodwires.kromat.Illuminant;
import org.goodwires.kromat.TransferFunction;

/**
 * iRGB specification 2017-07-20 (SWI)
 * for use by Greenwave with CTL Talk and other devices with RGB LED animation effects
 * @author SWI
 *
 */
public class CS_iRGB extends ColorSpace_RGB
{
	public CS_iRGB()
	{
		super("iRGB GWS 2017");				
		
		// iRGB discontinuous transfer function
		// f(x) = { x < d ? cx : (ax+b)^y }

		setTransferFunction(TransferFunction.yabcd(
				1.800000f,   // gamma
				0.952381f,   // a 
				0.047619f,   // b
				0.299555f,   // c
				0.040450f)); // d   

		// CIE xy vertices of primaries
		setPrimary_xy(0, new float[]{0.7100f,0.3000f}); // red  
		setPrimary_xy(1, new float[]{0.1200f,0.8600f}); // green
		setPrimary_xy(2, new float[]{0.1000f,0.0200f}); // blue
		
		setReferenceWhite_XYZ(Illuminant.D65().XYZ());	   // D65 white point
		compute(); // finalize								
	}


}
