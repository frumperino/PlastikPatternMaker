package org.goodwires.kromat.cs;

import org.goodwires.kromat.ColorSpace_RGB;
import org.goodwires.kromat.Illuminant;
import org.goodwires.kromat.TransferFunction;

/**
 * Academy Color Encoding System (ACES)
 * 
 * ACEScg linear wide-gamut profile with 
 * 
 * @author SWI
 *
 */
public class CS_ACES_cg extends ColorSpace_RGB
{
	public CS_ACES_cg()
	{
		super("ACES Linear");								       
		setTransferFunction(TransferFunction.linear());	// linear transfer function
		
		// CIE xy vertices of primaries (AP1)
		setPrimary_xy(0, new float[]{0.7130f,0.2930f}); // red  
		setPrimary_xy(1, new float[]{0.1650f,0.8300f}); // green
		setPrimary_xy(2, new float[]{0.1280f,0.0044f}); // blue
		
		setReferenceWhite_XYZ(Illuminant.D60().XYZ());
		compute(); // finalize								
	}


}
