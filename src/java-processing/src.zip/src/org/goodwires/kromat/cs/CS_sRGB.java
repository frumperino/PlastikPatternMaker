package org.goodwires.kromat.cs;

import org.goodwires.kromat.ColorSpace_RGB;
import org.goodwires.kromat.Illuminant;
import org.goodwires.kromat.TransferFunction;

public class CS_sRGB extends ColorSpace_RGB
{
	public CS_sRGB()
	{
		super("sRGB IEC61966-2.1");				
		
		// sRGB discontinuous transfer function ~ log 2.2
		// IEC 61966-2-1:1999
		// https://en.wikipedia.org/wiki/SRGB#The_sRGB_transfer_function_.28.22gamma.22.29

		// KROMAT adaptation:
		// f(x) = { x < d ? cx : (ax+b)^y }
		
		setTransferFunction(TransferFunction.yabcd(
				2.4f,		// gamma
				0.947867f,  // a
				0.052133f,  // b
				0.077399f,  // c
				0.040450f));// d

		// CIE xy vertices of primaries
		setPrimary_xy(0, new float[]{0.6400f,0.3300f}); // red  
		setPrimary_xy(1, new float[]{0.3000f,0.6000f}); // green
		setPrimary_xy(2, new float[]{0.1500f,0.0600f}); // blue

		setReferenceWhite_XYZ(Illuminant.D65().XYZ());	   // D65 white point
		compute(); // finalize								
	}


}
