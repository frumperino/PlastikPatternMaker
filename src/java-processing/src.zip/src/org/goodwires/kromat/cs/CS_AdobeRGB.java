package org.goodwires.kromat.cs;

import org.goodwires.kromat.ColorSpace_RGB;
import org.goodwires.kromat.Illuminant;
import org.goodwires.kromat.TransferFunction;

/**
 * AdobeRGB colorspace
 * @author SWI
 *
 */
public class CS_AdobeRGB extends ColorSpace_RGB
{
	public CS_AdobeRGB()
	{
		super("Adobe RGB (1998)");								       
		setTransferFunction(TransferFunction.log(536f/256f)); // Adobe RGB transfer function

		// CIE xy vertices of primaries
		setPrimary_xy(0, new float[]{0.6400f,0.3300f}); // red  
		setPrimary_xy(1, new float[]{0.2100f,0.7100f}); // green
		setPrimary_xy(2, new float[]{0.1500f,0.0600f}); // blue
		
		// setReferenceWhite_XYZ(new float[]{152.07f,160.00f,174.25f}); // for emissive use, effectively same as D65 ...
		setReferenceWhite_XYZ(Illuminant.D65().XYZ()); // ... so just use D65
		
		compute(); // finalize								
	}



}
