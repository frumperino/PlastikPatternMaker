package org.goodwires.kromat.cs;

import org.goodwires.kromat.ColorSpace_RGB;
import org.goodwires.kromat.Illuminant;
import org.goodwires.kromat.tf.TF_yabcd;

/**
 * Custom / tweakable RGB color space with parametric yabcd transfer function.
 * f(x) = { x < d ? cx : (ax+b)^y }
 * Initial state is identical to sRGB configuration
 * 
 * @author SWI
 *
 */
public class CS_custom extends ColorSpace_RGB
{
	private TF_yabcd customTF;
	private boolean _autoCompute = true;

	public enum E_standardColorspaces
	{
		/**
		 * Standard sRGB colorspace (gamma ~2.2)
		 */
		sRGB,
		
		/**
		 * Linear sRGB colorspace (same primaries, but gamma 1.0)
		 */
		sRGBL,
		
		/**
		 * Greenwave iRGB wide-gamut colorspace for RGB LED interfaces (gamma ~1.8)
		 */
		iRGB,
		
		/**
		 * "Talk" product LED profile (Everlight * TI linear 9-bit driver * Talk product light guide)
		 */
		TalkLED,
		
		/**
		 * Hobby-grade smart LEDs AKA SK6812 AKA Neopixels, linear 8-bit profile
		 */
		WS2812;
	};

	public CS_custom(String name)
	{
		super(name.length() == 0 ? "Custom RGB" : name);				
		
		// sRGB discontinuous transfer function ~ log 2.2
		// IEC 61966-2-1:1999
		// https://en.wikipedia.org/wiki/SRGB#The_sRGB_transfer_function_.28.22gamma.22.29
		// KROMAT adaptation:
		// f(x) = { x < d ? cx : (ax+b)^y }
		
		customTF = new TF_yabcd(
				2.4f,		// gamma
				0.947867f,  // a
				0.052133f,  // b
				0.077399f,  // c
				0.040450f);// d
		setTransferFunction(customTF);
		
		// CIE xy vertices of primaries
		setPrimary_xy(0, new float[]{0.6400f,0.3300f}); // red  
		setPrimary_xy(1, new float[]{0.3000f,0.6000f}); // green
		setPrimary_xy(2, new float[]{0.1500f,0.0600f}); // blue

		setReferenceWhite_XYZ(Illuminant.D65().XYZ());	   // D65 white point
		compute(); // finalize								
	}
	
	/**
	 * Enable or disable auto compute on external tweak of color primaries or white reference.
	 * @param enable
	 */
	public void setAutoCompute(boolean enable)
	{
		_autoCompute = enable;
	}
	
	/**
	 * f(x) = { x < d ? cx : (ax+b)^y }
	 * @return handle to tweakable yabcd transfer function
	 */
	public TF_yabcd getTransferFunction()
	{
		return customTF;
	}
	
	/**
	 * Set color primary
	 * @param index
	 * @param x
	 * @param y
	 */
	public void setPrimary(int index, float[] cie_xy)
	{
		setPrimary_xy(index, cie_xy);
		if (_autoCompute) { compute(); }
	}
	
	/**
	 * Set white reference
	 * @param cie_XYZ - CIE XYZ coordinates
	 */
	public void setWhiteReference(float[] cie_XYZ)
	{
		setReferenceWhite_XYZ(cie_XYZ);
		if (_autoCompute) { compute(); }
	}

	/**
	 * Load colorspace profile by name (must match string from E_standardColorspaces enum set)
	 * @param profile
	 */
	public void loadProfile(String profile)
	{
		try
		{
			loadProfile(E_standardColorspaces.valueOf(profile));
		}
		catch(Exception e)
		{
			// presumably invalid profile
			System.err.println("Error: invalid color space profile reference " + profile );
			e.printStackTrace();
		}
	}
	
	/**
	 * Load standard colorspace profile
	 * @param profile
	 */
	public void loadProfile(E_standardColorspaces profile)
	{
		boolean stored_autoCompute = _autoCompute;
		_autoCompute = false; // suspend autocompute temporarily
		
		switch(profile)
		{
			case iRGB:
			{
				customTF.setConstants(new float[]
				{
						1.800000f,   // gamma
						0.952381f,   // a 
						0.047619f,   // b
						0.299555f,   // c
						0.040450f	 // d   
				}); 
				setPrimary_xy(0, new float[]{0.7100f,0.3000f}); // red  
				setPrimary_xy(1, new float[]{0.1200f,0.8600f}); // green
				setPrimary_xy(2, new float[]{0.1000f,0.0200f}); // blue
				setReferenceWhite_XYZ(Illuminant.D65().XYZ());	   // D65 white point
				break;
			}
			case sRGB:
			{
				customTF.setConstants(new float[]
				{
						2.4f,		// gamma
						0.947867f,  // a
						0.052133f,  // b
						0.077399f,  // c
						0.040450f	// d
				});		
				// CIE xy vertices of primaries
				setPrimary_xy(0, new float[]{0.6400f,0.3300f}); // red  
				setPrimary_xy(1, new float[]{0.3000f,0.6000f}); // green
				setPrimary_xy(2, new float[]{0.1500f,0.0600f}); // blue
				setReferenceWhite_XYZ(Illuminant.D65().XYZ());	// D65 white point
				break;
			}
			case sRGBL:
			{
				customTF.makeLinear();
				// CIE xy vertices of primaries
				setPrimary_xy(0, new float[]{0.6400f,0.3300f}); // red  
				setPrimary_xy(1, new float[]{0.3000f,0.6000f}); // green
				setPrimary_xy(2, new float[]{0.1500f,0.0600f}); // blue
				setReferenceWhite_XYZ(Illuminant.D65().XYZ());	// D65 white point
				break;
			}
			case TalkLED:
			{
				customTF.makeLinear();
				setPrimary_xy(0, new float[]{0.6918f,0.3047f}); // red  
				setPrimary_xy(1, new float[]{0.1580f,0.7413f}); // green
				setPrimary_xy(2, new float[]{0.1434f,0.0516f}); // blue
				setReferenceWhite_XYZ(Illuminant.D65().XYZ());	// D65 white point
				break;
			}
			case WS2812:
			{
				customTF.makeLinear();
				setPrimary_xy(0, new float[]{0.6684f,0.3145f}); // red  
				setPrimary_xy(1, new float[]{0.2211f,0.7029f}); // green
				setPrimary_xy(2, new float[]{0.1425f,0.0799f}); // blue
				setReferenceWhite_XYZ(Illuminant.D65().XYZ());	// D65 white point
				break;
			}
		}
		compute();
		_autoCompute = stored_autoCompute; // restore auto mode enable state
	}

}
