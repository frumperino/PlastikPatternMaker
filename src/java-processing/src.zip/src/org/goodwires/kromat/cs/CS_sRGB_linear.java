package org.goodwires.kromat.cs;

import org.goodwires.kromat.*;

public class CS_sRGB_linear extends ColorSpace_RGB
{
	public CS_sRGB_linear()
	{
		super("sRGB Linear");
		
		setTransferFunction(TransferFunction.linear());
		
		// CIE xy vertices of primaries
		setPrimary_xy(0, new float[]{0.6400f,0.3300f}); // red  
		setPrimary_xy(1, new float[]{0.3000f,0.6000f}); // green
		setPrimary_xy(2, new float[]{0.1500f,0.0600f}); // blue

		setReferenceWhite_XYZ(Illuminant.D65().XYZ());	   // D65 white point
		compute(); // finalize								

	}
}
