package org.goodwires.kromat.cs;

import org.goodwires.kromat.ColorSpace_RGB;
import org.goodwires.kromat.Illuminant;
import org.goodwires.kromat.TransferFunction;

/**
 * Generic RGB LED colorspace 1 
 * 
 * <p/>
 * Based on datasheet from BIVAR PLCC6 RGB LED
 * which has an emissive spectrum that resembles typical WS2812 / SK6812 type smart LEDs.
 * LEDs
 * 
 * @author SWI
 *
 */
public class CS_LED1 extends ColorSpace_RGB
{
	public CS_LED1()
	{
		super("Generic LED");								       
		setTransferFunction(TransferFunction.linear());	// linear transfer function
		
		// CIE xy vertices of primaries
		setPrimary_xy(0, new float[]{0.6669f,0.3331f}); // red  
		setPrimary_xy(1, new float[]{0.2231f,0.7249f}); // green
		setPrimary_xy(2, new float[]{0.1225f,0.0876f}); // blue
		
		setReferenceWhite_XYZ(Illuminant.D65().XYZ());	   // D65 white point
		compute(); // finalize								
	}


}
