package org.goodwires.LEDpatternMaker;

public interface UIfeedbackHandler_I 
{
	public void ui_updateTimelinePosition(float v);
	public void ui_indicateRunning(boolean running);
	public void ui_indicateExportState(boolean writing);
	public void ui_updateSpeedKnob(float v);
	public void ui_updateStatusText(String text);
	public void ui_indicateOscillatorMode(int oscMode, String oscModeName);
	public void ui_indicateFilterMode(int filterMode);
	public void ui_indicateDitherMode(int ditherMode);
}
