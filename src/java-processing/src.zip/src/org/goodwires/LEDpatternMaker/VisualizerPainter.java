package org.goodwires.LEDpatternMaker;

import processing.core.*;

public abstract class VisualizerPainter 
{
	protected int color = 0x80800080;
	public abstract void paint(PGraphics pg);
	public void setColor(int color)
	{
		this.color = color;
	}
}
