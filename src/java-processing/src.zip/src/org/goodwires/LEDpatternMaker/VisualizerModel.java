package org.goodwires.LEDpatternMaker;

import processing.core.*;
import java.util.HashMap;

public class VisualizerModel
{
	HashMap<String, VisualizerGroup> groups;
	PGraphics mpg;
	private float csc;
	private float csx;
	private float csy;
	private boolean bgColorDefined = false;
	private int bgColor = 0;
	
	public VisualizerModel(PApplet pap, int w, int h, float offsetX, float offsetY, float scale)
	{
		groups = new HashMap<String, VisualizerGroup>();
		this.mpg = pap.createGraphics(w, h);
		this.csc = scale;
		this.csx = offsetX;
		this.csy = offsetY;
	}
	
	public void registerGroup(VisualizerGroup group, String name, float x, float y)
	{
		this.groups.put(name, group);
		group.setOffset(x,y);
	}
	
	public void loadColors(String name, int[] colors)
	{
		groups.get(name).loadColors(colors);
	}
	
	public void refresh() 
	{
		mpg.beginDraw();
		if (bgColorDefined)
		{
			mpg.background(bgColor);
		}
		else
		{
			mpg.clear();
		}
		for (VisualizerGroup g:groups.values())
		{
			g.paint(mpg);
		}
		mpg.endDraw();
	}

	public VisualizerGroup getGroup(String name) 
	{
		return groups.get(name);
	}
	
	public PImage getImage()
	{
		return this.mpg.get();
	}

	public void paintInContext(PGraphics pg)
	{
		pg.pushMatrix();
		pg.scale(csc);
		pg.translate(csx, csy);
		pg.image(mpg,0,0);
		pg.popMatrix();
	}

	public void setBackgroundColor(int bgcolor) 
	{
		this.bgColorDefined = true;
		this.bgColor = bgcolor;
	}

	public PGraphics getGraphics()
	{
		return this.mpg;
	}

	public void setFilterMode(int filterMode)
	{
		for(VisualizerGroup g:groups.values())
		{
			g.setFilterMode(filterMode);
		}
	}

}
