package org.goodwires.LEDpatternMaker.visuals;

import org.goodwires.LEDpatternMaker.VisualizerPainter;

import processing.core.*;

public class ShapePainter extends VisualizerPainter
{
	private PShape shape;

	public ShapePainter(PShape shape)
	{
		this.shape = shape;
		shape.setStroke(false);
	}
	
	@Override
	public void paint(PGraphics pg) 
	{
		shape.setFill(color);
		pg.shape(shape);
	}
	
}
