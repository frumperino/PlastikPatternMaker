package org.goodwires.LEDpatternMaker.visuals;

import org.goodwires.LEDpatternMaker.VisualizerPainter;

import processing.core.PGraphics;

public class CirclePainter extends VisualizerPainter 
{
	private float x;
	private float y;
	private float d;

	public CirclePainter(float x, float y, float d)
	{
		this.x = x;
		this.y = y;
		this.d = d;
	}
	
	public void paint(PGraphics pg) 
	{
		pg.noStroke();
		pg.fill(color);
		pg.ellipse(x,y,d,d);
	}
}
