package org.goodwires.LEDpatternMaker;

import java.util.HashMap;

import org.goodwires.kromat.*;

import processing.core.PImage;

public class Sampler
{
	private String name;
	private int numChannels;
	private int[] finishedSample;
	protected int sourceW;
	protected int sourceH;
	private boolean monoMode = false;
	private ChannelSampler[] channels;
	private float[][][] error;
	private int errorR = 0;
	private int errorW = 1;
	private ColorSpace_RGB sourceCS;
	private ColorSpace_RGB outputCS;
	private PImage sourceImage;
	private SamplerConfig config;
	private int filterMode = 0;
	private int ditherMode = 0;
	private int sampleCadence = 1;
	private HashMap<Integer,SamplerConfig> configPresets;
	private float t0 = 0.0f;
	private float t1 = 1.0f;

	public Sampler(String name, int numChannels) 
	{
		this.name = name;
		this.numChannels = numChannels;
		this.finishedSample = new int[numChannels];
		this.channels = new ChannelSampler[numChannels];
		for (int i=0;i<numChannels;i++)
		{
			channels[i] = new ChannelSampler();
		}
		sourceCS = ColorSpace.sRGB();
		outputCS = ColorSpace.sRGB();
		error = new float[2][numChannels][3];
		configPresets = new HashMap<Integer,SamplerConfig>();
	}

	/**
	 * @return last finished sample set (one 24-bit color per channel member)  
	 */
	public int[] getBuffer()
	{
		return finishedSample;
	}

	public String name()
	{
		return this.name;
	}
	
	public int numPixels()
	{
		return this.numChannels;
	}

	public Sampler setMono(boolean mono) 
	{
		this.monoMode = mono;
		return this;
	}
		
	/**
	 * Set output colorspace by name
	 * @param csName name of colorspace ("sRGB", "sRGB_linear", "WS2812", etc)
	 * @return
	 */
	public Sampler setOutputColorSpace(String csName) 
	{
		outputCS = ColorSpace_RGB.getByName(csName);
		return this;
	}
	
	/**
	 * Set output colorspace
	 * @param cs
	 * @return
	 */
	public Sampler setOutputColorSpace(ColorSpace_RGB cs)
	{
		outputCS = cs;
		return this;
	}

	public void updateSource(PImage sourceImage, ColorSpace_RGB sourceCS)
	{
		this.sourceW = sourceImage.width;
		this.sourceH = sourceImage.height;
		this.sourceImage = sourceImage;
		this.sourceCS = sourceCS;
		updateSamplerGeometry();
	}
	
	public void loadConfig(SamplerConfig config)
	{
		this.config = (SamplerConfig) config.clone();
		updateSamplerGeometry();
	}

	public void loadConfig(int index)
	{
		if (this.configPresets.containsKey(index))
		{
			loadConfig(configPresets.get(index));
		}
	}
	
	public Sampler storeConfig(int index, SamplerConfig config) 
	{
		this.configPresets.put(index,config);
		return this;
	}


	public void linkConfig(SamplerConfig config)
	{
		this.config = config;
		updateSamplerGeometry();
	}
	
	private void updateSamplerGeometry()
	{
		if (sourceH > 0)
		{
			float yrmin = config.y0 * (sourceH - 1);
			float yrmax = config.y1 * (sourceH - 1);
			float yrd = yrmax-yrmin;
			float ycmin = yrmin + t0 * yrd;
			float ycmax = yrmin + t1 * yrd;
			float ycstride = (ycmax-ycmin) / numChannels;
			float spread = ycstride * config.spatialSpread;
			float sss = spread / config.spatialSamples;
			float yc0 = (float) (ycmin + ycstride * 0.5 - 0.5 * spread);
			for (int i=0;i<numChannels;i++)
			{
				float yc = yc0 + i*ycstride;
				float y0 = yc + sss * 0.5f;
				int[] rows = new int[config.spatialSamples];
				for (int j=0;j<config.spatialSamples;j++)
				{
					rows[j] = (int) (y0 + j * sss);
				}
				channels[i].defineRows(rows);
			}
		}
	}

	private int[] temporalSample8bit(float x) 
	{
		int[] tmp = new int[numChannels];
		int ix = (int) Math.floor(x);
		int rx = (int) Math.floor(256 * (x - ix));
		if (rx < 1)
		{
			for (int i=0;i<numChannels;i++)
			{
				tmp[i] = channels[i].spatialAverageSample8bit(ix);
			}
		}
		else
		{
			for (int i=0;i<numChannels;i++)
			{
				int c1 = channels[i].spatialAverageSample8bit(ix);
				int c2 = channels[i].spatialAverageSample8bit(ix+1);
				tmp[i] = Util.interpolateColors(c1, c2, rx);
			}
		}
		return tmp;
	}
	

	private float[][] temporalSampleXYZ(float x)
	{
		float[][] tmp = new float[numChannels][3];
		int ix = (int) Math.floor(x);
		float rx = x - ix;
		for (int i=0;i<numChannels;i++)
		{
			float[] xyz1 = channels[i].spatialAverageSampleXYZ(ix);
			float[] xyz2 = channels[i].spatialAverageSampleXYZ(ix+1);
			tmp[i] = Util.interpolate(xyz1, xyz2, rx);
		}
		return tmp;
	}
	
	private void sampleWithCC(float samplePhase, int oscMode, float step) 
	{
		float pd = step / config.temporalSamples;
		float[][] xyzs = new float[numChannels][3];
		for (int i=0;i<config.temporalSamples;i++)
		{
			float x = (sourceW - 1) * Oscillator.progress(samplePhase + i * pd, oscMode);
			float[][] xyzt = temporalSampleXYZ(x);
			for (int j=0;j<numChannels;j++)
			{
				for (int k=0;k<3;k++)
				{
					xyzs[j][k] += xyzt[j][k];
				}
			}
		}
		int j0 = numChannels-1;
		int j1 = 1;
		for (int j=0;j<numChannels;j++)
		{
			for (int k=0;k<3;k++)
			{
				xyzs[j][k] /= config.temporalSamples;
			}
			float[] rgbf = outputCS.convert_XYZ2RGB(xyzs[j]);
			if (monoMode) 
			{ 
				float grey = 
						0.2126f * rgbf[0] +
						0.7152f * rgbf[1] +
						0.0722f * rgbf[2];
				if (ditherMode == 0)
				{
					int y8i = Math.round(255 * grey);
					finishedSample[j] = y8i | (y8i << 8) | (y8i << 16);
				}
				else
				{
					// Floyd-Steinberg
					float y8f = (255*grey) + error[errorR][j][0];  
					int y8i = Math.round(y8f);
					y8i = (y8i < 0 ? 0 : y8i > 255 ? 255 : y8i);
					finishedSample[j] = y8i | (y8i << 8) | (y8i << 16);
					float e16 = (y8f - y8i) / 16;
					error[errorR][j1][0] += e16*7;
					error[errorW][j1][0] += e16;
					error[errorW][j][0] += e16*5;
					error[errorW][j0][0] += e16*3;
				}
			}
			else
			{
				if (ditherMode == 0)
				{
					int r8 = Math.round(255 * rgbf[0]);
					int g8 = Math.round(255 * rgbf[1]);
					int b8 = Math.round(255 * rgbf[2]);
					finishedSample[j] = b8 | (g8 << 8) | (r8 << 16);
				}
				else
				{
					// Floyd-Steinberg
					int ci[] = new int[3];
					for (int k=0;k<3;k++)
					{
						float y8f = (255 * rgbf[k]) + error[errorR][j][k];
						int y8i = Math.round(y8f);
						y8i = (y8i < 0 ? 0 : y8i > 255 ? 255 : y8i);
						ci[k] = y8i;
						float e16 = (y8f - y8i) / 16;
						error[errorR][j1][k] += e16*7;
						error[errorW][j1][k] += e16;
						error[errorW][j][k] += e16*5;
						error[errorW][j0][k] += e16*3;
					}
					finishedSample[j] = ci[2] | (ci[1] << 8) | (ci[0] << 16);
				}
			}
			j1 = (j1+1) % numChannels;
			j0 = (j0+1) % numChannels;
		}
		
	}
	/**
	 * Straight 8-bit sample process with spatial and temporal oversampling
	 *  but with no dithering or color correction.
	 * @param samplePhase
	 * @param oscMode
	 * @param step
	 */
	private void sampleStraight(float samplePhase, int oscMode, float step) 
	{
		float pd = step / config.temporalSamples;
		int[][] tsum = new int[numChannels][3];
		for (int i=0;i<config.temporalSamples;i++)
		{
			float x = (sourceW - 1) * Oscillator.progress(samplePhase + i * pd, oscMode);
			int[] tmp = temporalSample8bit(x);
			for (int j=0;j<numChannels;j++)
			{
				int c = tmp[j];
				int r = (c >> 16) & 0xFF;
				int g = (c >> 8) & 0xFF;
				int b = c & 0xFF;
				tsum[j][0] += r;
				tsum[j][1] += g;
				tsum[j][2] += b;
			}
		}
		for (int j=0;j<numChannels;j++)
		{
			if (monoMode)
			{
				float[] rgb = new float[3];
				int d = config.temporalSamples * 255;
				for (int k=0;k<3;k++)
				{
					rgb[k] = (float) tsum[j][k] / d;
				}
				TransferFunction tfs = sourceCS.getTransferFunction();
				float r = 0.2126f * tfs.toLinear(rgb[0]);
				float g = 0.7152f * tfs.toLinear(rgb[1]);
				float b = 0.0722f * tfs.toLinear(rgb[2]);
				int yi = (int) Math.round(255 * tfs.toCompressed(r+g+b));
				finishedSample[j] = (yi << 16) | (yi << 8) | yi;
			}
			else
			{
				// color
				int r = tsum[j][0] / config.temporalSamples;
				int g = tsum[j][1] / config.temporalSamples;
				int b = tsum[j][2] / config.temporalSamples;
				finishedSample[j] = (r << 16) | (g << 8) | b;
			}
		}
	}
	
	public void sample(float samplePhase, int oscMode, float step) 
	{
		for (int i=0;i<numChannels;i++)
		{
			for (int j=0;j<3;j++)
			{
				error[errorR][i][j] = 0;
			}
		}
		errorR++;
		errorR &= 0x01;
		errorW = 1 ^ errorR;
		if (this.filterMode == 0)
		{
			sampleStraight(samplePhase, oscMode, step);
		}
		else
		{
			sampleWithCC(samplePhase, oscMode, step);
		}
	}


	public void setFilterMode(int filterMode)
	{
		this.filterMode = filterMode;
	}
	
	public void setDitherMode(int ditherMode)
	{
		this.ditherMode = ditherMode;
	}

	// =========================================================
	// CHANNEL SAMPLER SUBCLASS
	// =========================================================

	private class ChannelSampler
	{
		private int[] rowOffsets;
		/**
		 * Channel sums
		 */
		private int[] csum;
		
		ChannelSampler()
		{
			csum = new int[3];
		}
		
		public void defineRows(int[] rows)
		{
			int n = rows.length;
			this.rowOffsets = new int[n];
			for (int i=0;i<n;i++)
			{
				rowOffsets[i] = rows[i] * sourceW;
			}
		}

		protected float[] spatialAverageSampleXYZ(int ix)
		{
			float[] xyza = new float[3];
			for (int j=0;j<3;j++)
			{
				csum[j] = 0;
			}
			for (int i=0;i<config.spatialSamples;i++)
			{
				float[] xyz = sourceCS.convert_RGB2XYZ(sourceImage.pixels[rowOffsets[i]+ix]);
				for (int j=0;j<3;j++)
				{
					xyza[j] += xyz[j];
				}
			}
			for (int j=0;j<3;j++)
			{
				xyza[j] /= config.spatialSamples;
			}
			return xyza;
		}
		
		/**
		 * Perform 24-bit spatial oversampling 
		 * @param ix the x-coordinate for the sample  
		 * @return averaged 24-bit color value
		 */
		protected int spatialAverageSample8bit(int ix)
		{
			// null the buffer
			for (int j=0;j<3;j++)
			{
				csum[j] = 0;
			}
			for (int i=0;i<config.spatialSamples;i++)
			{
				int c = sourceImage.pixels[rowOffsets[i]+ix];
				for (int j=0;j<3;j++)
				{
					csum[2-j] += (c & 0xFF);
					c >>= 8;
				}
			}
			for (int j=0;j<3;j++)
			{
				csum[j] /= config.spatialSamples;
			}
			return (csum[0] << 16) | (csum[1] << 8) | csum[2];
		}
		
	}

	public Sampler setCadence(int i) 
	{
		this.sampleCadence = i;
		return this;
	}

	public Sampler trim(float t0, float t1) 
	{
		this.t0 = t0;
		this.t1 = t1;
		return this;
	}

	public int getCadence()
	{
		return this.sampleCadence;
	}

	public SamplerConfig getConfig() 
	{
		return this.config;
	}


}
