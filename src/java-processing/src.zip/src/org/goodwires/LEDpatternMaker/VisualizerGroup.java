package org.goodwires.LEDpatternMaker;

import java.util.ArrayList;
import java.util.Random;
import org.goodwires.kromat.*;

import org.goodwires.LEDpatternMaker.visuals.*;

import processing.core.*;

public class VisualizerGroup 
{
	ArrayList<VisualizerPainter> items;
	Random rand;
	private float offsetX;
	private float offsetY;
	
	protected int filterMode = LEDpatternMaker.FILTERMODE_CC;
	protected ColorSpace_RGB outputCS;
	private RGBtransformer rgbtrafo = null;
	
	public VisualizerGroup()
	{
		items = new ArrayList<VisualizerPainter>();
		rand = new Random();
		setOutputColorSpace(ColorSpace_RGB.sRGB());
	}
	
	public VisualizerGroup(PShape[] shapes) 
	{
		this();
		for (PShape p:shapes)
		{
			addShape(p);
		}
	}

	void clear()
	{
		items.clear();
	}
	
	void addShape(PShape shape)
	{
		items.add(new ShapePainter(shape));
	}
	
	void addCircle(float x, float y, float d)
	{
		items.add(new CirclePainter(x,y,d));
	}
	
	public int size()
	{
		return items.size();
	}
	
	public VisualizerPainter get(int index)
	{
		if (index < size())
		{
			return items.get(index);
		}
		return null;
	}
	
	public void loadColors(int[] colors)
	{
		int n = Math.min(colors.length,size());
		for (int i=0;i<n;i++)
		{
			setColor(i,colors[i]);
		}
	}
	
	public void setColor(int index, int color)
	{
		if (isIndexValid(index))
		{
			if (filterMode == 0)
			{
				items.get(index).setColor(color | 0xFF000000);
			}
			else
			{
				// apply color compensation
				int[] c1 = ColorSpace_RGB.expand_rgb24(color);
				int[] c2 = rgbtrafo.transform_RGB(c1, 8, 8);
				int c = 0xFF000000 | c2[2] | (c2[1] << 8) | (c2[0] << 16);
				items.get(index).setColor(c);
			}
		}
	}

	private boolean isIndexValid(int index)
	{
		return ((index >= 0) && (index < size()));
	}
	
	public void paint(PGraphics pg)
	{
		pg.pushMatrix();
		pg.translate(offsetX, offsetY);
		int n = size();
		for (int i=0;i<n;i++)
		{
			items.get(i).paint(pg);
		}
		pg.popMatrix();
	}

	public void loadRandomColors() 
	{
		int n = size();
		for (int i=0;i<n;i++)
		{
			items.get(i).setColor( 0xFF000000 | rand.nextInt(0xFFFFFF));
		}
	}

	public void setOffset(float x, float y) 
	{
		this.offsetX = x;
		this.offsetY = y;
	}

	public static VisualizerGroup createCircleGroup(PShape[] shapes, float diameter) 
	{
		VisualizerGroup vg = new VisualizerGroup();
		for (PShape shape:shapes)
		{
			PVector c = Util.getShapeCenter(shape);
			vg.addCircle(c.x, c.y, diameter);
		}
		return vg;
	}

	public void loadRandomColor()
	{
		int c = 0xFF000000 | rand.nextInt(0xFFFFFF);
		int n = size();
		for (int i=0;i<n;i++)
		{
			items.get(i).setColor(c);
		}
	}

	public void setFilterMode(int filterMode)
	{
		this.filterMode = filterMode;
	}

	public void setOutputColorSpace(String colorSpace) 
	{
		setOutputColorSpace(ColorSpace_RGB.getByName(colorSpace));
	}
	
	private void setOutputColorSpace(ColorSpace_RGB cs)
	{
		this.outputCS = cs;
		rgbtrafo = new RGBtransformer(outputCS,ColorSpace_RGB.sRGB());
	}


}
