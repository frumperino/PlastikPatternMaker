package org.goodwires.LEDpatternMaker;

public class SamplerConfig 
{
	private static final int _maxSpatialSamples = 32;
	private static final int _maxTemporalSamples = 8;

	/**
	 * The first row (proportional; 0..1f)
	 */
	public float y0 = 0f;
	
	/**
	 * The last row (proportional; 0..1f)
	 */
	public float y1 = 1f;
	
	/**
	 * The number of spatial subsamples
	 */
	public int spatialSamples = 1;
	
	/**
	 * The spread of spatial subsamples within channel slot (0..1f)
	 */
	public float spatialSpread = 1f;

	/**
	 * The number of temporal subsamples
	 */
	public int temporalSamples = 1;
	
	public SamplerConfig range(float y0, float y1)
	{
		this.y0 = (y0 < 0 ? 0 : y0 > 1 ? 1 : y0);
		this.y1 = (y1 < 0 ? 0 : y1 > 1 ? 1 : y1);
		return this;
	}
	
	public SamplerConfig spatialSamples(int numSpatialSamples)
	{
		this.spatialSamples = numSpatialSamples < 1 
				? 1 : numSpatialSamples > _maxSpatialSamples 
				? _maxSpatialSamples : numSpatialSamples;
		return this;
	}
	
	public SamplerConfig spatialSpread(float spatialSpread) 
	{
		this.spatialSpread = spatialSpread < 0 
				? 0 : spatialSpread > 1 
				? 1 : spatialSpread;
		return this;
	}

	public SamplerConfig temporalSamples(int numTemporalSamples)
	{
		this.temporalSamples = numTemporalSamples < 1 
				? 1 : numTemporalSamples > _maxTemporalSamples
				? _maxTemporalSamples : numTemporalSamples;
		return this;
	}
	
	public SamplerConfig clone()
	{
		SamplerConfig c = new SamplerConfig();
		c.range(y0, y1);;
		c.spatialSamples(spatialSamples);
		c.spatialSpread(spatialSpread);
		c.temporalSamples(temporalSamples);
		return c;
	}

	public static SamplerConfig standard()
	{
		SamplerConfig c = new SamplerConfig();
		c.range(0, 1);
		c.spatialSamples(1);
		c.spatialSpread(1);
		c.temporalSamples(1);
		return c;
	}
	
}
