package org.goodwires.LEDpatternMaker;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

import processing.core.*;
import processing.data.XML;
import processing.opengl.PGraphicsOpenGL;
import processing.opengl.PShapeOpenGL;

public class Util 
{
	public static int interpolateColors(int c1, int c2, int p)
	{
		p = (p < 0 ? 0 : p > 255 ? 255 : p);
		int r = 0;
		for (int i=3;i>=0;i--)
		{
			r <<= 8;
			int s8 = i << 3;
			r |= linterp((c1 >> s8) & 0xFF,(c2 >> s8) & 0xFF, p);
		}
		return r;
	}
	
	public static int linterp (int c1, int c2, int p)
	{
		return (int) (c1 + ((p * (c2-c1)) >> 8));
	}

	public static PVector getShapeCenter(PShape shape) 
	{
		float x0 = 99999;
		float x1 = -99999;
		float y0 = 99999;
		float y1 = -99999;
		int n = shape.getVertexCount();
		for (int i=0;i<n;i++)
		{
			PVector v = shape.getVertex(i);
			if (i==0)
			{
				x0 = v.x;
				x1 = v.x;
				y0 = v.y;
				y1 = v.y;
			}
			else
			{
				x0 = (v.x < x0 ? v.x : x0);
				x1 = (v.x > x1 ? v.x : x1);
				y0 = (v.y < y0 ? v.y : y0);
				y1 = (v.y > y1 ? v.y : y1);
			}
		}
		return new PVector ((x0+x1) / 2,(y0+y1) / 2);
	}
	
	public static PShape loadStreamSVGshape(InputStream rs, PGraphics pg) 
	{			
		if (rs != null)
		{
			try
			{
				XML x = new XML(rs);
				PShapeSVG svg = new PShapeSVG(x);
			    if (svg != null)
			    {
			      PShapeOpenGL p2d = PShapeOpenGL.createShape((PGraphicsOpenGL)pg, svg);
			      rs.close();
			      return p2d;
			    } 
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static InputStream getInStream(Object o, String className)
	{
		InputStream s = o.getClass().getResourceAsStream(className);
		if (s != null)
		{
			return s;
		}
		else
		{
			System.out.println("Resource not found: " + className);
			return null;
		}
	}


	public static PShape[] extractNamedShapes(PShape source, String[] names) 
	{
		int n = names.length;
		PShape[] r = new PShape[n];
		for (int i=0;i<n;i++)
		{
			String name = names[i];
			r[i] = extractNamedShape(source,name);
		}
		return r;
	}

	protected static PShape extractNamedShape(PShape source, String name)
	{
		return source.getChild(name);
	}
	
	public static PShape[] extractLayerMembers(PShape source, String string) 
	{
		PShape layer = source.getChild(string);
		return layer.getChildren();
	}

	public static PImage loadStreamImage(InputStream rs)
	{
		try
		{
			BufferedImage bimg = ImageIO.read(rs);
			PImage img = new PImage(bimg.getWidth(), bimg.getHeight(), PConstants.ARGB);
			bimg.getRGB(0, 0, img.width, img.height, img.pixels, 0, img.width);
			img.updatePixels();
			rs.close();
			return img;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}

	public static PImage loadFileImage(File file) 
	{
		try
		{
			BufferedImage bimg = ImageIO.read(file);
			PImage img = new PImage(bimg.getWidth(), bimg.getHeight(), PConstants.ARGB);
			bimg.getRGB(0, 0, img.width, img.height, img.pixels, 0, img.width);
			img.updatePixels();
			return img;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}
	
	public static PImage getResImage(Object o, String path) 
	{
		return loadStreamImage(getInStream(o,path));
	}

	public static PImage[] getResImageSet(Object o, String path, String[] names) 
	{
		int n = names.length;
		PImage[] r = new PImage[n];
		for (int i=0;i<n;i++)
		{
			r[i] = loadStreamImage(getInStream(o, path+names[i]));
		}
		return r;
	}
	
	public static PFont getResFont(Object o, String path) throws IOException
	{
		PFont f = new PFont(getInStream(o,path));
		return f;
	}

	public static float[] interpolate(float[] a, float[] b, float factor) 
	{
		int n = Math.min(a.length, b.length);
		float[] r = new float[n];
		for (int i=0;i<n;i++)
		{
			r[i] = a[i] + (b[i] - a[i]) * factor;
		}
		return r;
	}


}
