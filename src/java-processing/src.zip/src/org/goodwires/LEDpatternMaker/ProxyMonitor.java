package org.goodwires.LEDpatternMaker;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PImage;

public class ProxyMonitor 
{
	private static final int _LINESPACING = 2;
	
	PGraphics proxy = null;
	PImage cachedSource = null;
	private int w;
	private int h;
	private float x;
	private float y;
	private PApplet pap;
	private float xCursor = 0.5f;
	private boolean xCursorVisible = true;
	private ArrayList<Sampler> samplers = null;
	
	public ProxyMonitor(PApplet pap, int w, int h, float x, float y)
	{
		this.pap = pap;
		this.w = w;
		this.h = h;
		this.x = x;
		this.y = y;
		resize(w,h);
	}
	
	public void linkSamplers(ArrayList<Sampler> samplers)
	{
		this.samplers = samplers;
	}
	
	public float getXproportional(int mouseX) 
	{
		return (float) (mouseX-x) / (float) w;
	}
	
	public void setXcursorProportional(float cx)
	{
		xCursor = (cx < 0 ? 0 : cx > 1 ? 1 : cx);
	}
	
	public void setXcursorVisibility(boolean visible)
	{
		xCursorVisible = visible;
	}
	
	public void resize(int w, int h)
	{
		proxy = pap.createGraphics(w,h);
		if (cachedSource != null)
		{
			updateImage(cachedSource);
		}
	}
	
	public void updateImage(PImage source)
	{
		proxy.beginDraw();
		proxy.background(0);
		int srcW = source.width;
		int srcH = source.height;
		if (samplers == null)
		{
			proxy.image(source,0,0,w,h);
		}
		else
		{
			int n = samplers.size();
			float sh = (float) h / n;
			for (int i=0;i<n;i++)
			{
				Sampler sam = samplers.get(i);
				SamplerConfig cfg = sam.getConfig();
				int y0 = (int) (cfg.y0 * srcH);
				int y1 = (int) (cfg.y1 * srcH);
				int ymin = Math.min(y0, y1);
				int ymax = Math.max(y0, y1);
				proxy.copy(source, 0, ymin, srcW, ymax-ymin, 0, (int) (sh*i), w, (int) sh-_LINESPACING);
			}
		}
		proxy.endDraw();
		cachedSource = source;
	}
	
	public void paint(PGraphics pg)
	{
		pg.image(proxy,x,y);
		if (xCursorVisible)
		{
			float dx = (x+xCursor*w);
			pg.stroke(0x7F000000);
			pg.strokeWeight(3);
			pg.line(dx, y, dx, y+h);
			pg.stroke(0xFFFFFFFF);
			pg.strokeWeight(1);
			pg.line(dx, y, dx, y+h);
			pg.noStroke();
		}
	}

	public boolean isCoordinateInside(float tx, float ty)
	{
		if (tx < x) return false;
		if (ty < y) return false;
		if (tx > x+w) return false;
		if (ty > y+h) return false;
		return true;
	}

}
