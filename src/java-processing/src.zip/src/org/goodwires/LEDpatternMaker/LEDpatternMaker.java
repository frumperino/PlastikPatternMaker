package org.goodwires.LEDpatternMaker;

import processing.core.*;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.goodwires.kromat.*;
import com.hamoid.*;

public class LEDpatternMaker 
{
	private static final int _EXPORT_PATTERNSLICE_BATCH = 64;
	private static final int _EXPORT_VIDEOFRAME_BATCH = 8;

	private static final String _SYSTEM_CLASSPATH = "/org/goodwires/LEDpatternMaker";
	
	protected static final int _MAXTIME = 1000000;
	protected static final int _MAXSTEP = 50000;
	
	private static final int _MAXFRAMES = 4 * 60 * 120; // 4 minutes @ 120 Hz
	private static final int _MINSTEP = (int) Math.ceil( (float) _MAXTIME / _MAXFRAMES);
	
	private static final int _NUM_FILTER_MODES = 2;
	private static final int _NUM_DITHER_MODES = 2;

	public static final int FILTERMODE_DIRECT = 0;
	public static final int FILTERMODE_CC = 1;
	public static final int DITHERMODE_FLAT = 0;
	public static final int DITHERMODE_STEINBERG = 1;

	private static final int ExportMode_NONE = 0;
	private static final int ExportMode_PATTERN = 1;
	private static final int ExportMode_VIDEO = 2;

	
	private PGraphics pg;
	private JFileChooser jfc_import_image;
	private JFileChooser jfc_export_pattern;
	private JFileChooser jfc_export_video;
	private PImage sourceImage = null;
	private PApplet pap;
	private ProxyMonitor proxy = null;
	private VisualizerModel vmod = null;
	private int timeActual = 0;
	private int previewTimeStep = 10;
	private int patternTimeStep = 10;
	private int videoExportTimeStep = 10;
	private boolean proxyScrubMode = false;
	private int exportMode = 0;
	private int patternExportW = 0;
	private int patternExportH = 0;
	private boolean running = false;
	private UIfeedbackHandler_I uifbh = null;
	private float sourceImageSamplePhase = 0;
	private int sourceXmax = 0;
	private HashMap<String,Sampler> samplers;
	private ColorSpace_RGB sourceCS;
	private int oscillatorMode = Oscillator.LINEAR;
	private int filterMode = 0;
	private int ditherMode = 0;
	private PGraphics exportImage;
	private ArrayList<Sampler> samplerOrder;
	
	protected int patternExportFrameRate = 60; 
	protected int previewFrameRate = 60;
	protected int videoExportFrameRate = 60;
	private float exportFrameRate = 60;

	private File patternExportFile;
	private int patternExportSlice;
	private VideoExport videoExporter;
	private int storedFilterMode;
	private int storedDitherMode;


	protected LEDpatternMaker(PApplet pap)
	{
		this.pap = pap;
		this.pg = pap.g;
		
		jfc_import_image = new JFileChooser();
		jfc_import_image.addChoosableFileFilter(new FileNameExtensionFilter
				("Images", "jpg", "jpeg", "png", "gif", "bmp"));
		jfc_import_image.setAcceptAllFileFilterUsed(false);
		
		jfc_export_pattern = new JFileChooser();
		jfc_export_pattern.setApproveButtonText("Save pattern");
		jfc_export_pattern.setSelectedFile(new File("pattern.png"));
		
		jfc_export_video = new JFileChooser();
		jfc_export_video.setApproveButtonText("Save video");
		jfc_export_video.setSelectedFile(new File("pattern.mp4"));
		
		samplers = new HashMap<String,Sampler> ();
		samplerOrder = new ArrayList<Sampler> ();
	}
	
	// ==========================================================
	// HELPERS
	// ==========================================================
	
	protected String getBasePath()
	{
		String tmp = this.getClass().toString();
		tmp = tmp.substring(tmp.lastIndexOf(' ')+1);
		tmp = tmp.replace('.','/');
		tmp = "/" + tmp.substring(0, tmp.lastIndexOf('/')) ;
		return tmp;
	}

	protected PShape loadSVG(String respath)
	{
		String request = getBasePath() + respath;
		return Util.loadStreamSVGshape(Util.getInStream(this, request), pg);
	}


	// ==========================================================
	// KEY METHODS
	// ==========================================================

	protected void setPatternTimeStep(int t)
	{
		this.patternTimeStep = (t < _MINSTEP ? _MINSTEP : t > _MAXSTEP ? _MAXSTEP : t);
		patternExportW = (int) Math.ceil((float) _MAXTIME / patternTimeStep);

		this.previewTimeStep = 
				patternTimeStep * 
				patternExportFrameRate / 
				previewFrameRate; 

		this.videoExportTimeStep = 
				patternTimeStep * 
				patternExportFrameRate / 
				videoExportFrameRate;

		if (uifbh != null)
		{
			float v = ((float) t) / _MAXSTEP;
			uifbh.ui_updateSpeedKnob(v);
			
			float seconds = ((float) patternExportW) / patternExportFrameRate;
			int minutes = (int) Math.floor(seconds / 60);
			seconds -= 60*minutes;
			
			uifbh.ui_updateStatusText("Pattern duration: " 
			+ patternExportW + " frames (" 
			+ (minutes > 0 ? minutes + " minutes " : "")
			+ String.format("%.01f",seconds) + " seconds"
			+ " @" + String.format("%.01f",1f * patternExportFrameRate) + "Hz)");
		}
	}
	
	protected void gotoTime(int t)
	{
		timeActual = (t < 0 ? 0 : t % _MAXTIME);
		float phase = (float) timeActual / (_MAXTIME - 1);
		setSamplePhase(phase,oscillatorMode);
		if (uifbh != null)
		{
			uifbh.ui_updateTimelinePosition(phase);
		}
	}
	
	protected void setRunState(boolean running) 
	{
		if (!isExporting())
		{
			this.running = running;
			if (uifbh != null)
			{
				uifbh.ui_indicateRunning(running);
			}
		}
	}

	private void beginVideoExport(File selectedFile) 
	{
		if (vmod != null)
		{
			setRunState(false);
			System.out.println("Exporting video: " + selectedFile.getAbsolutePath());
			PGraphics pg = vmod.getGraphics();
			videoExporter = new VideoExport(pap,selectedFile.getAbsolutePath(),pg);
			videoExporter.setFrameRate(60);
			videoExporter.startMovie();
			this.gotoTime(0);
			saveFilterAndDitherMode();
			pm_setFilterMode(FILTERMODE_DIRECT);
			pm_setDitherMode(DITHERMODE_FLAT);
			vmod.setFilterMode(FILTERMODE_DIRECT);
			setExportMode(ExportMode_VIDEO);
		}
	}

	private void finishVideoExport()
	{
		if ((isExporting()) && (exportMode == ExportMode_VIDEO))
		{
			videoExporter.endMovie();
			setExportMode(ExportMode_NONE);
			restoreFilterAndDitherMode();
			vmod.setFilterMode(FILTERMODE_CC);
			this.gotoTime(0);
		}
	}
	
	private void saveFilterAndDitherMode() 
	{
		this.storedFilterMode = this.filterMode;
		this.storedDitherMode = this.ditherMode;
	}

	private void restoreFilterAndDitherMode() 
	{
		pm_setFilterMode(storedFilterMode);
		pm_setDitherMode(storedDitherMode);
	}

	private void beginPatternExport(File selectedFile) 
	{
		setRunState(false);
		this.patternExportFile = selectedFile;
		exportImage = pap.createGraphics(patternExportW, patternExportH);
		exportImage.beginDraw();
		exportImage.background(0xFFFF00FF);
		exportImage.endDraw();
		this.patternExportSlice = 0;
		this.gotoTime(0);
		setExportMode(ExportMode_PATTERN);
	}
	
	private void finishPatternExport() 
	{
		exportImage.save(patternExportFile.getAbsolutePath());
		setExportMode(ExportMode_NONE); // not exporting
		gotoTime(0);
	}

	private void setExportMode(int exportMode) 
	{
		this.exportMode = exportMode;
		if (uifbh != null)
		{
			uifbh.ui_indicateExportState(isExporting());
		}
	}

	private boolean isExporting() 
	{
		return (exportMode > 0);
	}

	private void exportVideoFrame()
	{
		if ((isExporting()) && (exportMode == ExportMode_VIDEO))
		{
			vmod.refresh();
			videoExporter.saveFrame();
			if (timeActual + videoExportTimeStep >= _MAXTIME)
			{
				finishVideoExport();
			}
			else
			{
				gotoTime(timeActual + videoExportTimeStep);
			}
		}
	}
	
	private void exportPatternSlice()
	{
		if ((isExporting()) && (exportMode == ExportMode_PATTERN))
		{
			exportImage.beginDraw();
			int yz = 0;
			for (Sampler s:samplerOrder)
			{
				int[] buf = s.getBuffer();
				int h = buf.length;
				for (int i=0;i<h;i++)
				{
					exportImage.set(patternExportSlice, yz++, 0xFF000000 | buf[i]);
				}
			}
			exportImage.endDraw();
			// advance
			patternExportSlice++;
			if (patternExportSlice >= patternExportW)
			{
				finishPatternExport();
			}
			else
			{
				gotoTime(timeActual + patternTimeStep);
			}
		}
	}

	protected void setFileImageSource(File file) 
	{
		PImage img = Util.loadFileImage(file);
		pm_setSourceImage(img);
	}
	
	
	protected void setCoreResourceSource(String coreResImageName) 
	{
		String request = _SYSTEM_CLASSPATH+"/res/" + coreResImageName;
		PImage img = Util.loadStreamImage(Util.getInStream(this, request));
		pm_setSourceImage(img);
	}

	protected void pm_setSourceImage(PImage img) 
	{
		setSourceImage(img, ColorSpace.sRGB());
	}

	protected void setSourceImage(PImage img, ColorSpace_RGB cs)
	{
		this.sourceImage = img;
		this.sourceImage.loadPixels();
		this.sourceXmax = img.width - 1;
		this.sourceCS = cs;
		updateSamplerGeometry();
		setSamplePhase(0.5f,Oscillator.LINEAR);
		updateSample(Oscillator.LINEAR);
	}
	
	/**
	 * Called whenever the source image has changed.
	 *  Update geometry for all samplers.
	 */
	private void updateSamplerGeometry() 
	{
		for (Sampler s:samplers.values())
		{
			s.updateSource(sourceImage, sourceCS);
		}
		if (proxy != null)
		{
			proxy.updateImage(sourceImage);
		}
	}

	private void setSamplePhase(float phase, int progressionMode) 
	{
		if (
				(sourceImage != null) && 
				(sourceXmax > 0) &&
				(phase >= 0) &&
				(phase <= 1)
				)
		{
			sourceImageSamplePhase = phase;
			updateSample(progressionMode);
			if (proxy != null)
			{
				proxy.setXcursorProportional(Oscillator.progress(phase, progressionMode));
			}
		}
	}

	private void updateSample()
	{
		if (sourceImage != null)
		{
			updateSample(this.oscillatorMode);
		}
	}
	
	private void updateSample(int oscillatorMode) 
	{
		float step = (float) this.previewTimeStep / _MAXTIME;
		for (String name:samplers.keySet())
		{
			Sampler sam = samplers.get(name);
			if (isExporting())
			{
				int c = sam.getCadence();
				if ((patternExportSlice % c) == 0)
				{
					sam.sample(sourceImageSamplePhase,oscillatorMode,step * c);
				}
			}
			else
			{
				// not exporting. 
				sam.sample(sourceImageSamplePhase,oscillatorMode,step);
			}
			if (vmod != null)
			{
				vmod.getGroup(name).loadColors(sam.getBuffer());
			}
		}
	}

	/**
	 * Tell samplers and visualizer elements that the color or filter modes have changed.
	 */
	private void notifyFilterAndDitherModeChange() 
	{
		for (String name:samplers.keySet())
		{
			Sampler sam = samplers.get(name);
			sam.setFilterMode(filterMode);
			sam.setDitherMode(ditherMode);
		}
		updateSample();
	}


	// ==========================================================
	// UI INPUT 
	// ==========================================================
	
	public void ui_handleMouseDown(int mouseX, int mouseY)
	{
		if ((ui_isMouseInsideProxy(mouseX,mouseY)) && (!isExporting()))
		{
			proxyScrubMode = true;
			setRunState(false);
		}
	}

	public void ui_handleMouseUp(int mouseX, int mouseY) 
	{
		proxyScrubMode = false;
	}
	
	public void ui_handleMouseDragged(int mouseX, int mouseY) 
	{
		if ((proxyScrubMode) && (!isExporting()))
		{
			float v = proxy.getXproportional(mouseX);
			setSamplePhase(v,Oscillator.LINEAR);
		}
	}

	private boolean ui_isMouseInsideProxy(int mouseX, int mouseY) 
	{
		if (proxy != null)
		{
			return proxy.isCoordinateInside(mouseX,mouseY);
		}
		return false;
	}
	
	// ==========================================================
	// API
	// ==========================================================

	protected void pm_toggleRunning() 
	{
		if (!isExporting())
		{
			setRunState(!running);
		}
	}

	protected void pm_promptImportImage() 
	{
		if (!isExporting())
		{
			int r = jfc_import_image.showOpenDialog(null);
			
			if (r == JFileChooser.APPROVE_OPTION)
			{
				File file = jfc_import_image.getSelectedFile();
				setFileImageSource(file);
			}
		}
	}
	
	protected void pm_promptExportPattern() 
	{
		if (!isExporting())
		{
			int r = jfc_export_pattern.showSaveDialog(null);
			if (r == JFileChooser.APPROVE_OPTION)
			{
				beginPatternExport(jfc_export_pattern.getSelectedFile());
			}
		}
	}
	
	protected void pm_promptExportVideo() 
	{
		if ((vmod != null) && (!isExporting()))
		{
			int r = jfc_export_video.showSaveDialog(null);
			if (r == JFileChooser.APPROVE_OPTION)
			{
				File f = jfc_export_video.getSelectedFile();
				if (f.exists())
				{
					f.delete();
				}
				beginVideoExport(f);
			}
		}
	}

	protected void pm_requestSpeed(float v) 
	{
		if (!isExporting())
		{
			setPatternTimeStep((int) (v * _MAXSTEP));
		}
	}

	protected void pm_requestTime(float v)
	{
		if (!isExporting())
		{
			gotoTime((int) (v * _MAXTIME));
		}
	}
	
	public void pm_cycleOscillatorMode() 
	{
		if (!isExporting())
		{
			pm_setOscillatorMode((oscillatorMode + 1) % Oscillator._NUM_OSCILLATOR_MODES);
		}
	}

	public void pm_setOscillatorMode(int mode)
	{
		if (!isExporting())
		{
			oscillatorMode = (mode < 0 ? 0 : mode % Oscillator._NUM_OSCILLATOR_MODES);
			if (uifbh != null)
			{
				uifbh.ui_indicateOscillatorMode(oscillatorMode, Oscillator.getProgressionModeName(mode));
			}
		}
	}
	
	public void pm_cycleFilterMode() 
	{
		if (!isExporting())
		{
			pm_setFilterMode((filterMode + 1) % _NUM_FILTER_MODES);
		}
	}

	public void pm_setFilterMode(int mode) 
	{
		if (!isExporting())
		{
			this.filterMode = ( mode < 0 ? 0 : mode % _NUM_FILTER_MODES);
			notifyFilterAndDitherModeChange();
			if (uifbh != null)
			{
				uifbh.ui_indicateFilterMode(this.filterMode);
			}
		}
	}

	public void pm_cycleDitherMode()
	{
		if (!isExporting())
		{
			pm_setDitherMode((ditherMode + 1) % _NUM_DITHER_MODES);
		}
	}
	
	public void pm_setDitherMode(int mode) 
	{
		if (!isExporting())
		{
			this.ditherMode = ( mode < 0 ? 0 : mode % _NUM_DITHER_MODES);
			notifyFilterAndDitherModeChange();
			if (uifbh != null)
			{
				uifbh.ui_indicateDitherMode(this.ditherMode);
			}
		}
	}

	protected void pm_loadSamplerConfigPreset(int v) 
	{
		if (!isExporting())
		{
			for (Sampler s:samplers.values())
			{
				s.loadConfig(v);
			}
			updateSample();
			updateSamplerGeometry();
		}
	}
	
	protected void pm_init()
	{
		if (proxy != null)
		{
			proxy.linkSamplers(samplerOrder);
			setCoreResourceSource("apple.png");
		}
	}

	// ==========================================================
	// CONFIGURE
	// ==========================================================


	public void pm_registerUIFBH(UIfeedbackHandler_I uif) 
	{
		this.uifbh = uif;
	}
	
	protected void pm_registerVisualizer(VisualizerModel vmod) 
	{
		this.vmod = vmod;
	}
	
	protected void pm_placeProxyWindow(int w, int h, float x, float y )
	{
		proxy = new ProxyMonitor(pap, w, h, x, y);
		if (sourceImage != null)
		{
			proxy.updateImage(sourceImage);
		}
	}

	public Sampler pm_createSampler(String name, int numPixels) 
	{
		Sampler s = new Sampler(name, numPixels);
		samplers.put(name,s);
		samplerOrder.add(s);
		patternExportH += numPixels;
		s.loadConfig(SamplerConfig.standard());
		return s;
	}

	// ==========================================================
	// PAINT 
	// ==========================================================

	public boolean step(PGraphics pg)
	{
		if (sourceImage == null)
		{
			setCoreResourceSource("apple.png");
			return false;
		}
		if (isExporting())
		{
			switch(exportMode)
			{
				case ExportMode_PATTERN: exportPatternSliceBatch(); break;
				case ExportMode_VIDEO: exportVideoFrameBatch(); break;
			}
		}
		else if (running)
		{
			gotoTime(timeActual + previewTimeStep);
		}
		else
		{
			gotoTime(timeActual);
		}
		paint(pg);
		return true;
	}

	private void exportVideoFrameBatch() 
	{
		for (int i=0;i<_EXPORT_VIDEOFRAME_BATCH;i++)
		{
			exportVideoFrame();
		}
	}

	private void exportPatternSliceBatch() 
	{
		for (int i=0;i<_EXPORT_PATTERNSLICE_BATCH;i++)
		{
			exportPatternSlice();
		}
	}
	
	protected void paint(PGraphics pg)
	{
		if (vmod != null)
		{
			vmod.refresh();
			vmod.paintInContext(pg);
		}
		if (proxy != null)
		{
			proxy.paint(pg);
		}
	}


}
