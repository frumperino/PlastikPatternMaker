package org.goodwires.LEDpatternMaker;

import java.util.Random;

public final class Oscillator 
{
	public static final int _NUM_OSCILLATOR_MODES = 4;

	/**
	 * Linear sweep
	 */
	public static final int LINEAR = 0;
	
	/**
	 * Reverse linear sweep
	 */
	public static final int REVERSE = 1;
	
	/**
	 * Linear pingpong (reverse direction at each end)
	 */
	public static final int PINGPONG = 2;
	
	/**
	 * Sine oscillate
	 */
	public static final int SINE = 3;
	
	private static final double pi2 = Math.PI * 2;

	static Random rand = new Random();
	
	public static float progress(float phase, int mode) 
	{
		if (phase < 0) { phase = 0; }
		if (phase > 1) { phase = (float) (phase - Math.floor(phase)); }
		switch(mode)
		{
			case REVERSE: return (1f - phase);
			case PINGPONG: return (phase >= 0.5 ? 1f - 2 * (phase - 0.5f) : phase * 2);
			case SINE: return (float) ( 0.5f - 0.5f * Math.cos(phase * pi2 ));
		}
		return phase;
	}

	public static String getProgressionModeName(int mode) 
	{
		switch(mode)
		{
			case 0: return "LINEAR";
			case 1: return "REVERSE";
			case 2: return "PINGPONG";
			case 3: return "SINE";
		}
		return "(undefined)";
	}
	
}
